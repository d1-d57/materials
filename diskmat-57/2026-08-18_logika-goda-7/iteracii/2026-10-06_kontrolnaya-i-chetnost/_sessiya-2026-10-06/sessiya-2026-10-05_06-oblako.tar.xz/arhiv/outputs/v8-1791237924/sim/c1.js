(function(){
var K=window.SimK,root=document.getElementById("sim-c1");if(!root||!K){return;}
var grid=root.querySelector(".c1-grid"),out=root.querySelector(".sim-out"),bs=root.querySelectorAll(".c1-b"),cells={},m="";
for(var d=1;d<=9;d++){for(var u=0;u<=9;u++){var n=10*d+u,c=document.createElement("div");c.className="c1-c";c.textContent=n;grid.appendChild(c);cells[n]=c;}}
function show(mm){m=(m===mm)?"":mm;var n,s,a,b,c,x;
for(n=10;n<=99;n++){c=cells[n];c.className="c1-c";x=c.querySelector(".c1-x");if(x){c.removeChild(x);}
s=String(n);a=s[0]==="7";b=s[1]==="7";
if(m==="a"&&a){c.classList.add("a");}
if(m==="b"&&b){c.classList.add("b");}
if((m==="ab"||m==="key")&&(a||b)){c.classList.add(a&&b?"ab":(a?"a":"b"));}}
if(m==="key"){x=document.createElement("span");x.className="c1-x";x.textContent="×2";cells[77].appendChild(x);}
for(var i=0;i<bs.length;i++){bs[i].classList.toggle("on",bs[i].getAttribute("data-m")===m);}
out.innerHTML={"":"Нажмите на кусок.","a":"Кусок «7 на первом месте»: от 70 до 79, <b>10</b> чисел.","b":"Кусок «7 на втором месте»: 17, 27, …, 97, <b>9</b> чисел.","ab":"10 + 9 = 19? У числа 77 два цвета — это двойник. Чисел <b>10 + 9 − 1 = 18</b>.","key":"Нажатий клавиши 7: число 77 печатают двумя нажатиями, поэтому <b>10 + 9 = 19</b> верно."}[m];}
for(var i=0;i<bs.length;i++){bs[i].addEventListener("click",function(){show(this.getAttribute("data-m"));});}
show("");
})();
