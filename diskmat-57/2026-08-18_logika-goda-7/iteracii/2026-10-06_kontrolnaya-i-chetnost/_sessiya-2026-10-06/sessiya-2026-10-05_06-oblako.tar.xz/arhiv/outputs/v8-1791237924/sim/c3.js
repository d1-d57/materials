(function(){
var K=window.SimK,root=document.getElementById("sim-c3");if(!root||!K){return;}
var box=root.querySelector(".c3-rows"),out=root.querySelector(".sim-out"),bs=root.querySelectorAll(".c3-b"),m="v";
function parts(n,mx){if(n===0){return [[]];}var r=[];for(var k=Math.min(n,mx);k>=1;k--){parts(n-k,k).forEach(function(p){r.push([k].concat(p));});}return r;}
var P=parts(6,6);
function uniq(p){var s={},c=0;p.forEach(function(x){if(!s[x]){s[x]=1;c++;}});return c;}
function draw(){K.clear(box);var tb=document.createElement("table"),tot=[];
var rows=m==="v"?[1,2,3,4,5,6].map(function(k){return ["есть "+k,P.filter(function(p){return p.indexOf(k)>=0;})];}):[6,5,4,3,2,1].map(function(f){return ["первое "+f,P.filter(function(p){return p[0]===f;})];});
rows.forEach(function(r){var tr=document.createElement("tr"),th=document.createElement("th"),td=document.createElement("td");th.textContent=r[0];
r[1].forEach(function(p){var e=document.createElement("span"),u=uniq(p);e.className="c3-k"+(m==="v"&&u===3?" t3":(m==="v"&&u===2?" t2":""));e.textContent=p.join("+");td.appendChild(e);});
var s=document.createElement("span");s.className="c3-s";s.textContent="— "+r[1].length;td.appendChild(s);tot.push(r[1].length);
tr.appendChild(th);tr.appendChild(td);tb.appendChild(tr);});
box.appendChild(tb);
for(var i=0;i<bs.length;i++){bs[i].classList.toggle("on",bs[i].getAttribute("data-m")===m);}
out.innerHTML=m==="v"?"У Васи <b>"+tot.join(" + ")+" = 19</b>. Разложение 3+2+1 лежит в трёх кусках, ещё шесть выделенных — в двух: двойники.":"У каждого разложения одно первое слагаемое: <b>"+tot.join(" + ")+" = 11</b>, двойников нет.";}
for(var i=0;i<bs.length;i++){bs[i].addEventListener("click",function(){m=this.getAttribute("data-m");draw();});}
draw();
})();
