import sys;sys.path.insert(0,'/tmp/claude-0/-home-claude/5fe2baf6-90cb-5754-9096-9aab3efe6076/scratchpad/fix')
from corpus import *
import re
pat=sys.argv[1]; w=int(sys.argv[2]) if len(sys.argv)>2 else 200
for k,v in {**PRIMARY,**SECOND}.items():
    for m in re.finditer(pat,v,flags=re.I):
        print(f'== {k} @{m.start()}: ...{v[max(0,m.start()-w):m.end()+w]}...'.replace('\n',' / '))
