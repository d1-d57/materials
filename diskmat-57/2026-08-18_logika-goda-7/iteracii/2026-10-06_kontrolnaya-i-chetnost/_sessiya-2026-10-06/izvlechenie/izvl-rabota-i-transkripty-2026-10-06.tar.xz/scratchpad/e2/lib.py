import json, re, sys
SRC="/mnt/user-data/uploads/materials/diskmat-57/2026-08-18_logika-goda-7/OTVETY-vladelca-2026-10-05.txt"
OUT="/mnt/user-data/outputs/izvl/out/E2.jsonl"
SRCNAME="OTVETY-vladelca-2026-10-05.txt (чат «Распознавание школьных работ»)"
raw=open(SRC,encoding="utf-8").read()
norm=lambda s: re.sub(r"\s+"," ",s)
NR=norm(raw)
import os
def count():
    return sum(1 for _ in open(OUT,encoding="utf-8")) if os.path.exists(OUT) else 0
def emit(rows):
    n=count()
    bad=[(r[1],r[4][:60]) for r in rows if r[4] and norm(r[4]) not in NR]
    if bad:
        print("BAD, nothing written:",bad); return
    with open(OUT,"a",encoding="utf-8") as f:
        for r in rows:
            kogda,mesto,vid,tekst,cit=r[:5]
            extra=r[5] if len(r)>5 else {}
            if cit and norm(cit) not in NR: bad.append((mesto,cit[:60]))
            n+=1
            d={"id":f"E2-{n:03d}","kogda":kogda,"istochnik":SRCNAME,"mesto":mesto,"kto":"vladelec","vid":vid,"tekst":tekst,"citata":cit}
            d.update(extra)
            f.write(json.dumps(d,ensure_ascii=False)+"\n")
    print("written",len(rows),"total",n,"BAD:",bad)
