import json,os
OUT='/mnt/user-data/outputs/izvl/out/E6.jsonl'
SRC='чат 4180f0ff (Пара 6.10 контрольные и лента урока)'
def _n():
    return sum(1 for _ in open(OUT,encoding='utf-8')) if os.path.exists(OUT) else 0
def add(rows):
    n=_n()
    with open(OUT,'a',encoding='utf-8') as f:
        for r in rows:
            n+=1
            kogda,mesto,kto,vid,tekst=r[:5]
            d=dict(id=f'E6-{n:03d}',kogda=kogda,istochnik=r[8] if len(r)>8 and r[8] else SRC,mesto=mesto,kto=kto,vid=vid,tekst=tekst)
            d['citata']=r[5] if len(r)>5 else ''
            if len(r)>6 and r[6]: d['pochemu']=r[6]
            if len(r)>7 and r[7]: d['imya']=r[7]
            f.write(json.dumps(d,ensure_ascii=False)+'\n')
    print('total',_n())
