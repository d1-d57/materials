from itertools import product
ds=lambda n: sum(map(int,str(n)))
isprime=lambda p: p>1 and all(p%d for d in range(2,p))
print("=== З3 простая сумма цифр ===")
two=range(10,100)
print("диапазон сумм:", min(map(ds,two)), max(map(ds,two)))
pr=[s for s in range(1,19) if isprime(s)]; print("простые суммы:", pr)
by={s:sum(1 for n in two if ds(n)==s) for s in pr}; print(by, "итого", sum(by.values()))
print("формулы s / 19-s совпадают:", all(by[s]==(s if s<=9 else 19-s) for s in pr))

print("\n=== флаги ===")
C="БКС"
flags=[f for f in product(C,repeat=3) if f[0]!=f[1] and f[1]!=f[2]]
print("флагов (палитра, соседние разные):", len(flags))
print("флагов (все три цвета):", sum(1 for f in product(C,repeat=3) if len(set(f))==3))
fl=["".join(f) for f in flags]; print("порядок Б<К<С:", fl)
i=fl.index("БСК"); print("после БСК:", fl[i+1], "| КББ допустим?", "КББ" in fl, "| КБС индекс", fl.index("КБС"), "КБК индекс", fl.index("КБК"))
for t in C: print("  кусок", t, sum(1 for f in fl if f[0]==t))

print("\n=== З4 разная чётность, сумма кратна 10 ===")
z4=[n for n in range(100,1000) if (n//100)%2!=(n//10%10)%2 and ds(n)%10==0]
print(len(z4))

print("\n=== семёрки ===")
s7=[n for n in two if '7' in str(n)]; print(len(s7), s7)
txt=[17,27,37,47,57,67,70,71,72,73,74,75,76,77,78,79,87,97]
print("список в тексте == истинный:", txt==s7, len(txt))
print("нажатий 7:", sum(str(n).count('7') for n in two))
print("первая 7:", sum(1 for n in two if n//10==7), " вторая 7:", sum(1 for n in two if n%10==7))

print("\n=== З6 9 или 15 ===")
th=range(100,1000)
m9=[n for n in th if n%9==0]; m15=[n for n in th if n%15==0]; m45=[n for n in th if n%45==0]
print(len(m9), m9[0], m9[-1], m9[0]//9, m9[-1]//9)
print(len(m15), m15[0], m15[-1], m15[0]//15, m15[-1]//15)
print(len(m45), m45[0], m45[-1], m45[0]//45, m45[-1]//45)
print("ответ:", sum(1 for n in th if n%9==0 or n%15==0))
print("180:", 180%9, 180%15, 180%135, "| кратных 135:", sum(1 for n in th if n%135==0))

print("\n=== З7 далматинцы ===")
L,R,N,T=29,17,22,101; both=T-L-R-N
print("оба:", both, "правое:", R+both, "101-22-29 =", T-N-L, "50-17=", 50-17)

print("\n=== пятёрки ===")
f5=[n for n in th if '5' in str(n)]; print("с пятёркой:", len(f5))
a=sum(1 for n in th if str(n)[0]=='5'); b=sum(1 for n in th if str(n)[1]=='5'); c=sum(1 for n in th if str(n)[2]=='5')
print("куски:", a,b,c, a+b+c)
print("без пятёрки:", sum(1 for n in th if '5' not in str(n)), "8*9*9=", 8*9*9, "900-648=", 900-648)
ab=sum(1 for n in th if str(n)[0]=='5' and str(n)[1]=='5'); ac=sum(1 for n in th if str(n)[0]=='5' and str(n)[2]=='5'); bc=sum(1 for n in th if str(n)[1]=='5' and str(n)[2]=='5')
print("ВИ:", a+b+c-ab-ac-bc+1, (ab,ac,bc))
print("505 в кусках:", [i for i in range(3) if '505'[i]=='5'], "555:", [i for i in range(3) if '555'[i]=='5'])

print("\n=== 17..23 ===")
print(len(range(17,24)), 23-16, 23-17)

print("\n=== З9 листы ===")
leaf=lambda p:(p+1)//2
print("лист стр.36:", leaf(36), (2*leaf(36)-1, 2*leaf(36)), " лист стр.91:", leaf(91), (2*leaf(91)-1,2*leaf(91)))
print("листов:", leaf(91)-leaf(36)+1)
# альтернативная разметка (чётная+нечётная на листе)
leaf2=lambda p:p//2
print("если на листе (2k,2k+1):", leaf2(91)-leaf2(36)+1)

print("\n=== З10 лестница ===")
fl1=5-1; t=60/fl1; print("пролётов 1->5:", fl1, "сек/пролёт", t, "1->10:", (10-1)*t, "сек =", divmod(int((10-1)*t),60))
print("1->25 пролётов:", 25-1, "отношение", (25-1)/(5-1))
