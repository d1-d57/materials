import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page(viewport={'width':1100,'height':900})
        await pg.goto('file:///mnt/user-data/outputs/pub/umnyj-perebor.html'); await pg.wait_for_timeout(600)
        info=await pg.evaluate("""()=>[...document.querySelectorAll('figure')].map((f,i)=>{const r=f.getBoundingClientRect();return [i,Math.round(r.width),Math.round(r.height),f.closest('details')?'details':'',getComputedStyle(f).display]})""")
        print(info)
        svgs=await pg.query_selector_all('figure svg')
        for i in (3,4):
            el=svgs[i]
            await pg.evaluate("e=>{let d=e.closest('details'); if(d) d.open=true; e.scrollIntoView()}", el)
        await pg.wait_for_timeout(300)
        for i in (3,4):
            try: await svgs[i].screenshot(path=f'f{i}.png', timeout=5000)
            except Exception as e: print('fail',i,str(e)[:80])
        await b.close()
asyncio.run(main())
