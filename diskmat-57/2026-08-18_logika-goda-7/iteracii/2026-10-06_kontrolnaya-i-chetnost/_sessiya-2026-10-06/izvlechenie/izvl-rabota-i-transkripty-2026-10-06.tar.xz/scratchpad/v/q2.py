exec(open("common.py").read())
import glob,json,html
corp=[]
for f in glob.glob('/mnt/user-data/uploads/materials/diskmat-57/**/*',recursive=True):
    if os.path.isfile(f) and f.endswith(('.md','.txt','.json','.jsonl','.html')):
        t=open(f,encoding='utf-8',errors='ignore').read()
        if f.endswith('.html'): t=html.unescape(re.sub(r'<[^>]+>',' ',t))
        corp.append(t)
for l in open('/mnt/user-data/outputs/handoff1006/sess/4180-repliki-vladelca-2026-10-06.jsonl',encoding='utf-8'):
    try:
        c=json.loads(l)['message']['content']; corp.append(c if isinstance(c,str) else json.dumps(c,ensure_ascii=False))
    except: pass
for u in U.values(): corp.append(u.get('citata','')+' \n '+u.get('tekst',''))
def N(s): return norm(s).lower().replace('„','"').replace('“','"').replace('<unk>','')
C=N(' \n '.join(corp))
C2=re.sub(r'[^\w]','',C)
tot=collections.Counter(); bad=collections.defaultdict(list)
for d,t in DOM.items():
    for m in re.finditer(r'«((?:[^«»]|«[^«»]*»)*)»',t):
        q=m.group(1)
        ctx=t[max(0,m.start()-80):m.start()]
        for f in re.split(r'…|\.\.\.',q):
            f2=N(f).strip(' .,;:!?')
            if len(f2)<25: continue
            tot[d]+=1
            if f2 in C: continue
            if re.sub(r'[^\w]','',f2) in C2: continue
            bad[d].append((f2[:110], N(ctx)[-60:]))
for d in sorted(tot): print(d, tot[d], len(bad[d]))
json.dump(bad,open('badquotes.json','w'),ensure_ascii=False,indent=0)
