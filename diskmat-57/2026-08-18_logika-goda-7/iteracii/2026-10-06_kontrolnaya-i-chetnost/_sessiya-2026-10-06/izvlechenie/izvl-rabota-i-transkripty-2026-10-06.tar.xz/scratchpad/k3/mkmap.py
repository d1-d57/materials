import json,re,collections,sys
md=open('/mnt/user-data/outputs/izvl/dom/K3-BANK-zadach-para-6-10.md',encoding='utf-8').read()
ids=[json.loads(l)['id'] for l in open('/mnt/user-data/outputs/izvl/vhod/K3.jsonl')]
S=set(ids)
occ=collections.defaultdict(list)  # id -> [(level, anchor)]
lvl,anchor=None,None
for line in md.split('\n'):
    m=re.match(r'^(#{2,4}) (.*)',line)
    if m:
        lvl=len(m.group(1)); h=m.group(2)
        anchor=h.split(' · ')[0].strip() if lvl==4 else re.split(r' [(]| —', h)[0].strip()
        continue
    for br in re.findall(r'\[([^\[\]]*E\d-\d{3}[^\[\]]*)\]',line):
        for i in re.findall(r'E\d-\d{3}',br):
            occ[i].append((lvl,anchor))
bad=[i for i in occ if i not in S]; miss=[i for i in ids if i not in occ]
print('not in input:',bad); print('missing:',miss)
home={}
amb={}
for i in ids:
    o=occ.get(i,[])
    r4=list(dict.fromkeys(a for l,a in o if l==4))
    if len(r4)==1: home[i]=r4[0]
    elif len(r4)>1: amb[i]=r4; home[i]=r4[0]
    else: home[i]=list(dict.fromkeys(a for l,a in o))[0]
print('ambiguous:',amb)
json.dump(home,open('home.json','w'),ensure_ascii=False)
