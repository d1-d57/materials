import json,difflib
base='/mnt/user-data/outputs/handoff1006/sess/4180-repliki-vladelca-2026-10-06.jsonl'
txt=''.join(json.loads(l)['message']['content']+'\n' for l in open(base,encoding='utf-8'))
for l in open('/mnt/user-data/outputs/izvl/out/E5.jsonl',encoding='utf-8'):
    r=json.loads(l)
    if r['citata'] in txt or r['istochnik']!='4180-repliki-vladelca-2026-10-06.jsonl': continue
    c=r['citata']
    # find by sliding: longest prefix
    best=0;bi=0
    for k in range(10,len(c)+1,5):
        i=txt.find(c[:k])
        if i<0: break
        best=k;bi=i
    # then show where diverge
    print(r['id'],'prefix ok',best,'of',len(c))
    print('  MINE:',c[best-20:best+60].replace('\n','\\n'))
    print('  SRC :',txt[bi+best-20:bi+best+60].replace('\n','\\n'))
