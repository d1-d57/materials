import itertools
F=[f for f in itertools.product('БКС',repeat=3) if f[0]!=f[1] and f[1]!=f[2]]
def adj(a,b): return sum(x!=y for x,y in zip(a,b))==1
best=0
def dfs(p,used):
    global best
    best=max(best,len(p))
    for f in F:
        if f not in used and adj(p[-1],f):
            used.add(f);p.append(f);dfs(p,used);p.pop();used.remove(f)
for s in F: dfs([s],{s})
print(len(F),best)
