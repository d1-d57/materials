exec(open('load.py').read())
H='/mnt/user-data/uploads/materials/diskmat-57/2026-08-18_logika-goda-7/'
def src(t):
    f=t.split(';')[0].split(' ')[0]
    for base in [H, '/mnt/user-data/uploads/materials/diskmat-57/']:
        p=base+f
        if os.path.exists(p): return open(p,encoding='utf-8').read()
    return ''
bank=DOM['K3-BANK-zadach-para-6-10.md']
bl=bank.split('\n')
def rec(i):
    out=[]
    for j,l in enumerate(bl):
        if re.search(re.escape(i)+r'(?!\d)',l):
            s=j
            while s>0 and not bl[s].startswith('#'): s-=1
            e=j+1
            out.append('\n'.join(bl[s:e]))
    return '\n'.join(out)
res=[]
for k,i,t in EST:
    if k!='K3': continue
    u=U[i]; txt=u['tekst']+' '+u.get('citata','')
    nums=set(re.findall(r'\d+',txt))
    S=src(t); R=rec(i)
    miss_s=[n for n in nums if n not in S]
    miss_r=[n for n in nums if n not in R]
    res.append((i,t,len(nums),miss_s,miss_r,len(S)))
for r in res: print(r[0], 'nums',r[2],'missSRC',r[3],'missBANK',r[4],'srclen',r[5])
