import asyncio
from playwright.async_api import async_playwright
P='/mnt/user-data/uploads/materials/diskmat-57/2026-08-18_logika-goda-7/iteracii/2026-10-06_kontrolnaya-i-chetnost/statya-urok-1/LENTA/publish-v3.html'
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page(viewport={'width':390,'height':900})
        await pg.goto('file://'+P); await pg.wait_for_timeout(800)
        r=await pg.evaluate('''()=>{const W=document.documentElement.clientWidth;const o=[];for(const e of document.querySelectorAll('body *')){const r=e.getBoundingClientRect();if(r.right>W+1&&r.width>0){let s=e;let inScroll=false;while(s&&s!==document.body){const cs=getComputedStyle(s);if(cs.overflowX==='auto'||cs.overflowX==='scroll'){inScroll=true;break}s=s.parentElement}if(!inScroll)o.push(e.tagName+'.'+e.className+' r='+Math.round(r.right)+' '+(e.textContent||'').slice(0,40))}}return [document.documentElement.scrollWidth,o.slice(0,8)]}''')
        print(r)
        f=await pg.query_selector_all('figure'); await f[0].screenshot(path='g0.png')
        await b.close()
asyncio.run(main())
