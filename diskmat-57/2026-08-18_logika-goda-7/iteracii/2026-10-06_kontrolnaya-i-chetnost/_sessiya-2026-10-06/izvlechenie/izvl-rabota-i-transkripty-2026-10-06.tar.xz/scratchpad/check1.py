from collections import Counter
from math import ceil

print("=== 1. МОНЕТЫ ===")
allsets = [(a,b,c) for a in range(3) for b in range(6) for c in range(11) if 5*a+2*b+c==10]
print("всего наборов (5,2,1):", len(allsets), allsets)

def parse(s):
    coins = [int(x) for x in s.split('+')]
    return (coins.count(5), coins.count(2), coins.count(1)), sum(coins)

chaotic = ["5+5","2+2+2+2+2","5+2+2+1","5+1+1+1+1+1","2+5+1+2","2+2+2+2+1+1","+".join(["1"]*10),"5+2+1+1+1"]
parsed = [parse(s) for s in chaotic]
print("записей:", len(chaotic))
for s,(t,sm) in zip(chaotic,parsed):
    print(f"  {s:25s} -> {t} сумма {sm}")
invalid = [s for s,(t,sm) in zip(chaotic,parsed) if sm!=10]
print("негодных записей (сумма != 10):", invalid)
cnt = Counter(t for t,_ in parsed)
print("повторы:", {k:v for k,v in cnt.items() if v>1})
print("разных:", len(cnt))
missing = [t for t in allsets if t not in cnt]
print("пропущены:", missing)

print("\n--- цепочка Васи ---")
cur = (2,0,0); chain=[cur]
while True:
    a,b,c = cur
    if a>0: cur=(a-1,b+2,c+1)
    elif b>0: cur=(a,b-1,c+2)
    else: break
    chain.append(cur)
def show(t):
    a,b,c=t; return "+".join(["5"]*a+["2"]*b+["1"]*c)
for t in chain: print("  ", show(t), t, "монет:", sum(t))
text_chain = ["5+5","5+2+2+1","2+2+2+2+1+1","2+2+2+1+1+1+1","2+2+1+1+1+1+1+1","2+1+1+1+1+1+1+1+1","+".join(["1"]*10)]
print("цепочка совпадает с текстом:", [parse(s)[0] for s in text_chain]==chain, "| суммы в тексте:", [parse(s)[1] for s in text_chain])
print("повторы в цепочке:", len(chain)!=len(set(chain)))
print("не в цепочке:", [show(t) for t in allsets if t not in chain])
print("в каждом наборе после первого есть рубль:", all(t[2]>=1 for t in chain[1:]))
print("в хаотичном списке, но не в цепочке:", [show(t) for t in cnt if t not in chain])
# таблица
for a in (2,1,0):
    rows=[t for t in allsets if t[0]==a]
    print(f"  пятёрок {a}: двушек {[t[1] for t in sorted(rows,key=lambda t:t[1])]}, наборов {len(rows)}")

print("\n=== 2. СУММА ЦИФР 5 ===")
nums=[n for n in range(100,1000) if sum(map(int,str(n)))==5]
print("всего:", len(nums), nums)
ch2="500, 230, 113, 401, 122, 320, 311, 104, 212, 410, 131, 203, 302, 221, 050".split(", ")
print("записей в хаотичном:", len(ch2), "повторы:", [k for k,v in Counter(ch2).items() if v>1])
print("суммы цифр в хаотичном:", set(sum(map(int,x)) for x in ch2))
print("лишние (не трёхзначные/не из ряда):", [x for x in ch2 if not (x[0]!='0' and int(x) in nums)])
print("пропущены:", [n for n in nums if str(n) not in ch2])
table={1:[104,113,122,131,140],2:[203,212,221,230],3:[302,311,320],4:[401,410],5:[500]}
for a,lst in table.items():
    real=[n for n in nums if n//100==a]
    print(f"  первая {a}: текст {lst} == {real}: {lst==real}, 6-a={6-a}, len={len(real)}")
