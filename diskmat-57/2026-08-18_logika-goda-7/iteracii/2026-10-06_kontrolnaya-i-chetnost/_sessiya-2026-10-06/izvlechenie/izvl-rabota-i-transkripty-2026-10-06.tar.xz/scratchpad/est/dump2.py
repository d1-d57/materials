exec(open('load.py').read())
K=sys.argv[1]; out=[]
lines={n:txt.split('\n') for n,txt in DOM.items()}
for k,i,t in EST:
    if k!=K: continue
    u=U[i]
    hits=[]
    for n,ls in lines.items():
        for j,l in enumerate(ls):
            if re.search(re.escape(i)+r'(?!\d)',l):
                # for bank records, include preceding block up to header
                if n.startswith('K3'):
                    s=j
                    while s>0 and not ls[s].startswith('#'): s-=1
                    hits.append(f'{n}:{s+1}-{j+1}: '+' / '.join(x.strip() for x in ls[s:j+1])[:2500])
                else:
                    hits.append(f'{n}:{j+1}: '+l[:2000])
    out.append(f"===== {i} [{u['kto']}/{u['vid']} {u['kogda']}] KUDA: {t}\n  T: {u['tekst']}\n  C: {u.get('citata','')}\n  P: {u.get('pochemu','')}\n  "+'\n  '.join('>> '+h for h in hits))
open(f'dump-{K}.txt','w').write('\n'.join(out)); print(len('\n'.join(out)))
