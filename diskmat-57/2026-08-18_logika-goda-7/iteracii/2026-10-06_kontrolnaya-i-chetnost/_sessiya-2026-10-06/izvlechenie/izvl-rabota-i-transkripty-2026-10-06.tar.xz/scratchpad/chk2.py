from itertools import product
def parts(n,m=None):
    m=m or n
    if n==0: yield (); return
    for k in range(min(n,m),0,-1):
        for r in parts(n-k,k): yield (k,)+r
P=list(parts(6)); print(len(P), ['+'.join(map(str,p)) for p in P])
def comps(n):
    if n==0: yield (); return
    for k in range(1,n+1):
        for r in comps(n-k): yield (k,)+r
print('comps',len(list(comps(6))))
haos=[(2,4),(1,)*6,(1,2,1,2),(3,3),(1,5),(1,1,2,1,1),(2,3,1),(6,),(1,1,3,1),(2,1,1,2),(2,2,2)]
hs=[tuple(sorted(h,reverse=True)) for h in haos]; print(len(haos), len(set(hs)), set(P)-set(hs))
# отщипываем единичку
c=[(6,)];
while c[-1][0]>1:
    x=list(c[-1]); x[0]-=1; x.append(1); c.append(tuple(sorted(x,reverse=True)))
print('otshchip',len(c),c)
# по количеству слагаемых
from collections import Counter; print(Counter(len(p) for p in P))
fl=[''.join(f) for f in product('БКС',repeat=3) if f[0]!=f[1] and f[1]!=f[2]]; print(fl)
adj={a:[b for b in fl if sum(x!=y for x,y in zip(a,b))==1] for a in fl}
best=0
def dfs(v,seen):
    global best; best=max(best,len(seen))
    for w in adj[v]:
        if w not in seen: dfs(w,seen|{w})
for v in fl: dfs(v,{v})
print('longest one-stripe chain',best)
# по верхней: кусок
print(Counter(f[0] for f in fl))
