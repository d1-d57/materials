from playwright.sync_api import sync_playwright
import pathlib
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page()
    pg.goto("file://"+str(pathlib.Path("figs.html").resolve()))
    r=pg.evaluate("""()=>{const s=document.querySelectorAll('svg')[0];const o=[];s.querySelectorAll('text').forEach(t=>{const y=+t.getAttribute('y');if(y<=26){const b=t.getBBox();o.push([t.textContent,+b.x.toFixed(1),+b.y.toFixed(1),+(b.x+b.width).toFixed(1),+(b.y+b.height).toFixed(1)])}});return o}""")
    hdr=[x for x in r if x[0].startswith('послед')][0]; print(hdr)
    for x in r:
        if x is hdr: continue
        if x[1]<hdr[3] and x[3]>hdr[1] and x[2]<hdr[4] and x[4]>hdr[2]: print("пересечение bbox:",x)
    b.close()
