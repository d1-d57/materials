import re
L=open('/mnt/user-data/outputs/statya-urok-1/LENTA/lenta.md',encoding='utf-8').read().split('\n')
svg=L[94]
# cells: up-t texts with x,y
cells=re.findall(r'<text class="up-t" x="([\d.]+)" y="([\d.]+)"[^>]*font-weight="(\d+)">(\d+)</text>',svg)
colx={55+42*i:i for i in range(10)}; rowy={49+28*j:j+1 for j in range(9)}
bad=[];bold=set()
for x,y,w,t in cells:
    c=colx[int(float(x))]; r=rowy[int(float(y))]
    if int(t)!=10*r+c: bad.append((x,y,t))
    if int(w)>=600: bold.add(int(t))
print("ячеек:",len(cells),"несовпадений:",bad)
print("жирные:",sorted(bold), len(bold))
print("жирные == числа с 7:", bold==set(n for n in range(10,100) if '7' in str(n)))
rects=re.findall(r'<rect class="(up-\w+)" x="([\d.]+)" y="([\d.]+)" width="([\d.]+)" height="([\d.]+)"',svg)
from collections import Counter
print(Counter(r[0] for r in rects))
for r in rects:
    if r[0]!='up-c': print(r)
paths=re.findall(r'<path class="(up-\w+)" d="([^"]+)"',svg); print(paths)
