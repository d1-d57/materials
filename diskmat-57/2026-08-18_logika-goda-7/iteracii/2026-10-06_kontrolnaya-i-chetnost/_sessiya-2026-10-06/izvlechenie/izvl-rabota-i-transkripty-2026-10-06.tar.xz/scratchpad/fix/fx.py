import sys;sys.path.insert(0,'.')
from rep import rep
rep('/mnt/user-data/outputs/izvl/dom/K1-RESHENIYA-novye.md',[('в транскрипте сессии , L657.','в транскрипте сессии `transkript-2026-09-29_10-05.jsonl`, L657.')])
