import json,re
base='/mnt/user-data/outputs/handoff1006/sess/4180-repliki-vladelca-2026-10-06.jsonl'
txt=''.join(json.loads(l)['message']['content']+'\n' for l in open(base,encoding='utf-8'))
txt+=open('/mnt/user-data/uploads/materials/diskmat-57/2026-08-18_logika-goda-7/SESSIYA.md',encoding='utf-8').read()
txt+="\nотлично! запнятие прошло. чуть позже запишу подробный отчет, но пока можно двигаться к закрытию по дисциплине хендоффа. только очень очень аккуратно\nты сделал все за один раз? ничего не забыл? нужно вывезти все, что мы могли потерять\nХорошо, давай максимально полно все вытащим, чтобы все решения, идеи, люди и контекст остались с нами навсегда"
bad=0
for l in open('/mnt/user-data/outputs/izvl/out/E5.jsonl',encoding='utf-8'):
    r=json.loads(l)
    if r['citata'] not in txt:
        bad+=1; print(r['id'],r['citata'][:80])
print('bad',bad)
