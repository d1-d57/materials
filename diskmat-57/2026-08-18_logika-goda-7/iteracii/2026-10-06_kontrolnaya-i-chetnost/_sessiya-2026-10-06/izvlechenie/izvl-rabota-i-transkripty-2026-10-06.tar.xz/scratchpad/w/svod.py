import json,re,glob
D='/mnt/user-data/outputs/izvl/dom/'
docs={f.split('/')[-1]:open(f,encoding='utf-8').read() for f in glob.glob(D+'*.md')}
def bullets(text):
    # split into records: bullet items or paragraphs
    recs=[];cur=[]
    for line in text.split('\n'):
        if re.match(r'\s*(- |\* |\d+\. |#|\|)',line) or not line.strip():
            if cur: recs.append('\n'.join(cur))
            cur=[line] if line.strip() else []
        else:
            cur.append(line)
    if cur: recs.append('\n'.join(cur))
    return recs
R={n:bullets(t) for n,t in docs.items()}
res=json.load(open('res.json'))
for x in res:
    hits=[]
    for n,recs in R.items():
        for rec in recs:
            if re.search(re.escape(x['id'])+r'(?!\d)',rec): hits.append((n,rec))
    x['svod']=hits
json.dump(res,open('res.json','w',encoding='utf-8'),ensure_ascii=False,indent=0)
import collections
print(collections.Counter((x['K'],len(x['svod'])) for x in res))
