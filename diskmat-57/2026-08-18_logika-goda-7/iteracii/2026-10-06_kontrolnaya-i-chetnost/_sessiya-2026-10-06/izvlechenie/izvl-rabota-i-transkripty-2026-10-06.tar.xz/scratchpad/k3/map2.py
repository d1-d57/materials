import json,collections
home=json.load(open('home.json'))
over={'E3-166':'Г-5'}
for i in ['E6-150','E6-154','E6-159','E6-160','E6-161','E6-162','E6-163','E8-613','E8-643']:
    pass
home['E6-150']='В-5';home['E6-154']='В-3';home['E6-159']='В-6';home['E6-160']='В-7';home['E6-161']='В-8';home['E6-162']='В-9';home['E6-163']='В-10';home['E8-613']='В-3';home['E8-643']='МЛ-3'
home.update(over)
K='iteracii/2026-10-06_kontrolnaya-i-chetnost/'
I='ITOGI-2026-10-05/'
EST={}
def e(lst,where):
    for x in lst.split(): EST[x]=where
e('E8-024','%sKONCEPCIYA-6-10.md §2, §3.3'%K)
e('E8-036','%sKONCEPCIYA-6-10.md §3.2'%K)
e(' '.join(f'E8-0{n}' for n in range(43,50))+' E3-193 E3-194 E3-195 E3-196 E3-197 E3-198 E3-199','%sKONCEPCIYA-6-10.md §4 «Лист для верха»'%K)
e(' '.join(f'E8-0{n}' for n in range(50,63))+' E3-200 E3-201 E3-202','%sKONCEPCIYA-6-10.md §5 «Базовая контрольная»'%K)
e('E8-074 E3-248 E3-249','%sBRAINSTORM-perebor.md §1 «Хаос»'%K)
e('E8-090 E3-252','%sBRAINSTORM-perebor.md §3 «Флаги»'%K)
e('E8-098 E8-099 E8-100 E8-101 E8-102 E8-103 E8-104 E3-253 E3-254 E3-255','%sBRAINSTORM-perebor.md §4 «Найди ошибку»'%K)
e(' '.join(f'E8-{n}' for n in range(125,138))+' E3-272 E3-273 E3-274 E3-275 E3-276','%sKR-6-10-chernovik.md (таблица v1)'%K)
e('E8-160','%sLESTNICA-PEREBOR.md §3 ступень 0; §7 п.3'%K)
e('E8-165','%sLESTNICA-PEREBOR.md §3 ступень 1'%K)
e('E8-171','%sLESTNICA-PEREBOR.md §3 ступень 1, запасной ход'%K)
e('E8-173','%sLESTNICA-PEREBOR.md §3 ступень 2'%K)
e('E8-188','%sLESTNICA-PEREBOR.md §3 ступень 3'%K)
e('E8-193','%sLESTNICA-PEREBOR.md §3 ступень 4'%K)
e('E8-201 E8-202','%sLESTNICA-PEREBOR.md §3 ступень 6'%K)
e('E8-221','%sLESTNICA-PEREBOR.md §7 п.8 ДЗ «Вася по строкам»'%K)
e('E3-347 E3-348 E3-350 E3-351','%s02-odna-ideya.md'%I)
e('E3-365 E3-366 E3-369','%s04-idei-uroka.md «Принято»/«Открыто»'%I)
e('E3-372','%s04-idei-uroka.md «Связь с ДЗ к 6.10»'%I)
e('E3-376 E3-377','%s05-kontrolnaya.md «Черновик v1 (05.10 16:35)»'%I)
e('E3-380 E3-381','%s06-bank.md «Малые задачи на перебор»'%I)
e('E3-382 E3-383','%s06-bank.md «Ложные правила (14 штук)»'%I)
e('E2-229','docs/RESHENIYA.md Р240 (R3 — в КР с другими числами)')
e('E2-242','docs/RESHENIYA.md Р242 («Забор из 6 пролётов» — слишком просто для КР)')
DUBL=dict(x.split('>') for x in '''E8-288>E6-030 E8-289>E6-031 E8-292>E6-032 E8-294>E6-034 E8-296>E6-035 E8-297>E6-036
E8-458>E6-298 E6-153>E8-612 E6-149>E8-608 E6-151>E8-610 E6-152>E8-611 E6-154>E8-613 E8-632>E8-613
E8-547>E8-563 E8-548>E8-565 E8-539>E8-564 E6-130>E8-549 E6-060>E8-459 E6-088>E6-057 E6-089>E6-307 E8-650>E6-222
E6-183>E7-114 E6-192>E7-114 E8-324>E7-114 E6-184>E7-115 E6-194>E7-115 E8-325>E7-115
E6-185>E7-116 E6-196>E7-116 E8-326>E7-116 E6-204>E7-130
E6-186>E7-117 E6-197>E7-117 E8-327>E7-117 E6-210>E7-135 E8-318>E7-135
E6-187>E7-118 E6-198>E7-118 E8-328>E7-118 E6-209>E7-134 E8-317>E7-134
E6-188>E7-119 E6-199>E7-119 E8-329>E7-119 E6-273>E7-238 E8-346>E7-238
E6-189>E7-120 E8-344>E7-236 E6-190>E7-122 E6-206>E7-131 E8-314>E7-131 E8-343>E7-235
E6-207>E7-132 E8-315>E7-132 E6-208>E7-133 E8-316>E7-133
E8-342>E7-234 E6-268>E7-237 E8-345>E7-237 E6-269>E7-241 E8-349>E7-241 E6-270>E7-240 E8-348>E7-240
E6-271>E7-239 E8-347>E7-239 E8-350>E7-242 E6-274>E7-243 E8-351>E7-243 E6-275>E7-244 E8-352>E7-244
E6-260>E7-218 E8-385>E7-218 E4-352>E4-308 E4-429>E3-252 E4-282>E8-202'''.split())
ids=[json.loads(l)['id'] for l in open('/mnt/user-data/outputs/izvl/vhod/K3.jsonl')]
B='K3-BANK-zadach-para-6-10.md'
out=[];cnt=collections.Counter()
for i in ids:
    a=home[i]
    if i in DUBL:
        t=DUBL[i]; assert t in home, t
        k=('dubl',f'{t} (та же задача, тот же источник; запись {B} §{home[t]})')
    elif i in EST:
        k=('est',f'{EST[i]}; сослано в {B} §{a}')
    else:
        k=('novoe',f'{B} §{a}')
    cnt[k[0]]+=1
    out.append(f'{i}\t{k[0]}\t{k[1]}')
assert not (set(DUBL)&set(EST))
open('/mnt/user-data/outputs/izvl/dom/map-K3.tsv','w',encoding='utf-8').write('\n'.join(out)+'\n')
print(len(out),cnt)
# dubl targets should not be dubl themselves
print([t for t in DUBL.values() if t in DUBL])
