import json,glob,re,os,sys
IZ='/mnt/user-data/outputs/izvl'
U={}
for f in sorted(glob.glob(IZ+'/out/E*.jsonl')):
    for l in open(f,encoding='utf-8'):
        l=l.strip()
        if l:
            d=json.loads(l); U[d['id']]=d
EST=[]
for k in ['K1','K2','K3']:
    for l in open(f'{IZ}/dom/map-{k}.tsv',encoding='utf-8'):
        p=l.rstrip('\n').split('\t')
        if len(p)>=3 and p[1]=='est': EST.append((k,p[0],p[2]))
R={}
for l in open('/mnt/user-data/uploads/materials/diskmat-57/docs/RESHENIYA.md',encoding='utf-8'):
    m=re.match(r'^\| (Р\d+)',l)
    if m: R.setdefault(m.group(1),'');R[m.group(1)]+=l
DOM={os.path.basename(f):open(f,encoding='utf-8').read() for f in glob.glob(IZ+'/dom/*.md')}
