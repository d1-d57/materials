import re
L=open('/mnt/user-data/outputs/statya-urok-1/LENTA/lenta.md',encoding='utf-8').read().split('\n')
f2=L[121]; f3=L[136]
print("--- рисунок 2 (далматинцы) ---")
rects=re.findall(r'<rect class="(up-\w+)" x="([\d.]+)" y="[\d.]+" width="([\d.]+)"',f2)
tot=sum(float(w) for _,_,w in rects)
for (c,x,w),n in zip(rects,[22,29,17,33]):
    print(c,x,w,"-> доля*101 =",round(float(w)/tot*101,2),"ожидалось",n)
print("сумма ширин",tot)
print(re.findall(r'>([^<>]+)</text>',f2))
print(re.findall(r'<path class="(up-\w+)" d="([^"]+)"',f2))
print("--- рисунок 3 (ряд 1..23) ---")
cells=re.findall(r'<rect class="(up-\w+)" x="(\d+)" y="40" width="24" height="30"/><text[^>]*>(\d+)</text>',f3)
print(len(cells), "серых:",[int(t) for c,_,t in cells if c=='up-s'][-1:], "выделено:",[int(t) for c,_,t in cells if c=='up-a'])
print("номера по порядку и x согласованы:",all(int(t)==i+1 and int(x)==14+24*i for i,(c,x,t) in enumerate(cells)))
print("серые = 1..16:",[int(t) for c,_,t in cells if c=='up-s']==list(range(1,17)))
print(re.findall(r'<path class="(up-\w+)" d="([^"]+)"',f3))
print([t for t in re.findall(r'>([^<>]+)</text>',f3) if not t.isdigit()])
