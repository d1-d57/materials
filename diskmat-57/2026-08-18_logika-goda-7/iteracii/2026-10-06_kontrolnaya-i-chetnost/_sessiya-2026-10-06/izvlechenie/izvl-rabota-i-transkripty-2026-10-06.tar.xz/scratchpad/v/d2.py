exec(open('load.py').read())
import json
S=json.load(open('sample.json'))
R='/mnt/user-data/uploads/materials/diskmat-57/2026-08-18_logika-goda-7/'
j=[]
for l in open('/mnt/user-data/outputs/handoff1006/sess/4180-repliki-vladelca-2026-10-06.jsonl',encoding='utf-8'):
    try:
        d=json.loads(l); c=d['message']['content']
        if isinstance(c,list): c=' '.join(x.get('text','') for x in c if isinstance(x,dict))
        j.append(c)
    except: pass
J=norm(' \n '.join(j)).lower(); SS=norm(open(R+'SESSIYA.md',encoding='utf-8').read()).lower()
cnt=collections.Counter()
for scope,ids in [('sample',S['D']['E5']),('all',[i for i,u in U.items() if i.startswith('E5-') and u['kto']=='vladelec'])]:
    for i in ids:
        c=norm(U[i].get('citata','')).lower()
        inj=c in J; ins=c in SS
        cnt[(scope,'jsonl' if inj else ('sessiya-only' if ins else 'none'))]+=1
        if scope=='sample' and not inj: print(i,U[i].get('mesto'),'|',U[i]['citata'][:160])
print(cnt)
