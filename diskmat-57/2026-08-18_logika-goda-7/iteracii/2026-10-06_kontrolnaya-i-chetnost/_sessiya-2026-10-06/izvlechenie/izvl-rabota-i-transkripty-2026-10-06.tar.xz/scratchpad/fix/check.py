import sys;sys.path.insert(0,'/tmp/claude-0/-home-claude/5fe2baf6-90cb-5754-9096-9aab3efe6076/scratchpad/fix')
from corpus import *
files=sys.argv[1:]
tot=0;nf=0
for fn in files:
    t=open(fn,encoding='utf-8').read()
    for pos,q in quotes(t):
        line=t.count('\n',0,pos)+1
        ps=pieces(q)
        if not ps: continue
        tot+=1
        bad=[]
        for p in ps:
            a,b=where(p)
            if not a: bad.append((p,b))
        if bad:
            nf+=1
            print(f'{fn.split("/")[-1]}:{line}: «{q[:160]}»')
            for p,b in bad: print('    NOT:',p[:120],'| sec:',b)
print('total',tot,'notfound',nf,file=sys.stderr)
