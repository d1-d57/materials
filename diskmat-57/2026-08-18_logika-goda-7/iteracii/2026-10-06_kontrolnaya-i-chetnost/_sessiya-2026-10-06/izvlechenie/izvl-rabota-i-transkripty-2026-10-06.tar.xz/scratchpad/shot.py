import asyncio
from playwright.async_api import async_playwright
P='/mnt/user-data/uploads/materials/diskmat-57/2026-08-18_logika-goda-7/iteracii/2026-10-06_kontrolnaya-i-chetnost/statya-urok-1/LENTA/publish-v1.html'
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch()
        for w,name in [(1280,'d'),(390,'m')]:
            pg = await b.new_page(viewport={'width':w,'height':900})
            errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
            await pg.goto('file://'+P); await pg.wait_for_timeout(800)
            sw = await pg.evaluate('document.documentElement.scrollWidth')
            figs = await pg.query_selector_all('figure')
            for i,f in enumerate(figs):
                await f.screenshot(path=f'fig{i}_{name}.png')
            await pg.screenshot(path=f'top_{name}.png')
            print(w, 'scrollWidth', sw, 'figs', len(figs), 'errors', errs[:3])
        await b.close()
asyncio.run(main())
