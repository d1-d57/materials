import json,re
exec(open('pipe.py').read().split("rows = [l.rstrip")[0])
res=json.load(open('res.json'))
for x in res:
    parts=targets(x['kuda']); corpus='\n'.join(t or '' for _,t in parts); cT=toks(corpus)
    ut=toks(x['tekst']+' '+x['pochemu']); ct=toks(x['citata'])
    x['missw']=sorted((ut|ct)-cT)
    x['missw_t']=sorted(ut-cT)
json.dump(res,open('res.json','w',encoding='utf-8'),ensure_ascii=False,indent=0)
