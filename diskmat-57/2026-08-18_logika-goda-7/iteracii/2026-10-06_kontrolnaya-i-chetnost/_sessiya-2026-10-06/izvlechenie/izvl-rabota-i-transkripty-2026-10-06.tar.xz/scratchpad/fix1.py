import sys,json; sys.path.insert(0,'/tmp/claude-0/-home-claude/5fe2baf6-90cb-5754-9096-9aab3efe6076/scratchpad')
from h import *
rows=[json.loads(l) for l in open(OUT,encoding='utf-8')]
for r in rows:
    if r['tekst'].startswith('Интервью 22:00 (виджет): КР в двух вариантах'):
        r['citata']='Интервью 22:00 (виджет): А и Б;'
    if r['tekst'].startswith('Из исследования (без отметки'):
        r['vid']='ideya'; r['tekst']='Из прошлого исследования (владелец напоминает): порядок тем — по возрастанию абстрактности: правило разности → умный перебор → формула включения-исключения в конце как пропедевтика на будущее; если не хватает времени на ФВИ — не страшно; но сейчас последовательность в статье неправильная.'
    if r['tekst'].startswith('Порядок работы: НЕ «сначала обе КР'):
        r['citata']=q('Начать с ленты.','особенно с этим перебором.','**1. «Порядок')
with open(OUT,'w',encoding='utf-8') as f:
    for r in rows: f.write(json.dumps(r,ensure_ascii=False)+'\n')
