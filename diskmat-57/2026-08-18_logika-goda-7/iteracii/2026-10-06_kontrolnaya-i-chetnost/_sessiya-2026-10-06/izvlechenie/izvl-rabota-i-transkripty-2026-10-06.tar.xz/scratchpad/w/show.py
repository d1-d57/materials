import json,sys,re
sys.path.insert(0,'.')
r=json.load(open('res.json'))
K=sys.argv[1]; lo=int(sys.argv[2]) if len(sys.argv)>2 else 0; hi=int(sys.argv[3]) if len(sys.argv)>3 else 9999
mode=sys.argv[4] if len(sys.argv)>4 else 'best'
xs=[x for x in r if x['K']==K][lo:hi]
for x in xs:
    print('=== %s [%s/%s %s] cov=%s cit=%s miss=%s → %s'%(x['id'],x['vid'],x['kto'],x['kogda'],x['cov'],x['citin'],x['missnum'],x['kuda'][:150]))
    print('T:',x['tekst'])
    if x['citata']: print('C:',x['citata'][:400])
    if x['pochemu']: print('P:',x['pochemu'][:250])
    if mode=='best':
        for s,c in x['best'][:1]: print('  >>',s,re.sub(r'\s+',' ',c)[:380])
