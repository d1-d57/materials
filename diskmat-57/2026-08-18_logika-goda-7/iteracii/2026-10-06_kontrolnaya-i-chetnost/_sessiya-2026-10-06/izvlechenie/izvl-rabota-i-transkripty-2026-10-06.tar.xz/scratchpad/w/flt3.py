import sys,re,html
# print: assistant text outside tools, full Write/Edit content, SESSIYA/RESHENIYA commands, AskUserQuestion, SendUserMessage, Agent prompts; others truncated to 250
t=html.unescape(open(sys.argv[1],encoding='utf-8').read())
pos=0;out=[]
for m in re.finditer(r'<tool name="([^"]+)">(.*?)</tool>',t,flags=re.S):
    out.append(t[pos:m.start()]); pos=m.end()
    n,b=m.group(1),m.group(2)
    full = n in('Write','Edit','AskUserQuestion','SendUserMessage','Agent','Artifact','SendUserFile') or 'SESSIYA' in b or 'RESHENIYA' in b
    out.append(f'\n<<{n}: {b if full else b[:250].replace(chr(10)," ")}>>\n')
out.append(t[pos:])
print(''.join(out))
