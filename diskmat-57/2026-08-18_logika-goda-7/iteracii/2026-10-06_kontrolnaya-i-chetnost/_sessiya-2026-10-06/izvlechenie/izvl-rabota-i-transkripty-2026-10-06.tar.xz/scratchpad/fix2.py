import json
base='/mnt/user-data/outputs/handoff1006/sess/4180-repliki-vladelca-2026-10-06.jsonl'
txt=''.join(json.loads(l)['message']['content']+'\n' for l in open(base,encoding='utf-8'))
O='/mnt/user-data/outputs/izvl/out/E5.jsonl'
rows=[json.loads(l) for l in open(O,encoding='utf-8')]
rep={'E5-014':[('То есть я не понимаю общей философии.','То есть я не понимаю. Вот. Дальше я не понимаю общей философии.')],
'E5-046':[('что в столбцах.','что там в столбцах.')],
'E5-088':[('времени? Понимаешь?','времени. Понимаешь?')],
'E5-090':[('Во-вторых, я думаю','Вторых, я думаю')],
'E5-093':[('Давайте теперь','давайте теперь')],
'E5-131':[('Первая понимаю','первая понимаю')],
'E5-149':[('И вообще','и вообще')],
'E5-164':[('Самое главное','самое главное')],
'E5-167':[('Но может быть','но может быть')]}
for r in rows:
    for a,b in rep.get(r['id'],[]):
        r['citata']=r['citata'].replace(a,b)
with open(O,'w',encoding='utf-8') as f:
    for r in rows: f.write(json.dumps(r,ensure_ascii=False)+'\n')
