exec(open("common.py").read())
R='/mnt/user-data/uploads/materials/diskmat-57/2026-08-18_logika-goda-7/'
SRC=norm(open(R+'OTVETY-vladelca-2026-10-05.txt',encoding='utf-8').read()+open(R+'OTVETY-vladelca-2026-10-04.txt',encoding='utf-8').read()+open(R+'SESSIYA.md',encoding='utf-8').read()+open('/mnt/user-data/outputs/handoff1006/sess/4180-repliki-vladelca-2026-10-06.jsonl',encoding='utf-8').read().encode().decode('unicode_escape','ignore') if False else '').lower()
import json
src=open(R+'OTVETY-vladelca-2026-10-05.txt',encoding='utf-8').read()+open(R+'OTVETY-vladelca-2026-10-04.txt',encoding='utf-8').read()+open(R+'SESSIYA.md',encoding='utf-8').read()
for l in open('/mnt/user-data/outputs/handoff1006/sess/4180-repliki-vladelca-2026-10-06.jsonl',encoding='utf-8'):
    try:
        c=json.loads(l)['message']['content']; src+='\n'+(c if isinstance(c,str) else json.dumps(c,ensure_ascii=False))
    except: pass
SRC=norm(src).lower()
def frags(q):
    return [norm(x).strip(' .,;:').lower() for x in re.split(r'…|\.\.\.',q) if len(norm(x).strip(' .,;:'))>=12]
res=[]
for sec in ['A']:
  for k,ids in S[sec].items():
    for i in ids:
        u=U[i]
        if u['kto']!='vladelec': continue
        kk,ish,kuda=M[i][0]
        docs=[d for d in DOM if d in kuda] or [d for d in DOM if d.startswith(k+'-')]
        for d in docs:
            for r in record(d,i):
                ids_in=re.findall(r'E\d-\d{3}',r)
                pool=' || '.join(norm(U[x].get('citata','')+' '+U[x].get('tekst','')).lower() for x in ids_in if x in U)
                # owner quotes in record: any «» quote
                for q in re.findall(r'«((?:[^«»]|«[^«»]*»)*)»',r):
                    for f in frags(q.replace('„','"').replace('“','"')):
                        f2=f.replace('„','"').replace('“','"')
                        inpool=f2 in pool.replace('„','"').replace('“','"')
                        insrc=f2 in SRC.replace('„','"').replace('“','"')
                        if not inpool and not insrc:
                            res.append((i,d,f[:120]))
for x in sorted(set(res)): print(x)
print(len(set(res)))
