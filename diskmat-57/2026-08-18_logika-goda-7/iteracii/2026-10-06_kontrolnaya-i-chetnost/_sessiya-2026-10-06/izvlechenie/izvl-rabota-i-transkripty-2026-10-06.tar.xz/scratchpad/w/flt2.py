import sys,re,html
t=html.unescape(open(sys.argv[1],encoding='utf-8').read())
for m in re.finditer(r'<tool name="([^"]+)">(.*?)</tool>',t,flags=re.S):
    b=m.group(2)
    if ('SESSIYA' in b or 'RESHENIYA' in b) and m.group(1)=='mcp__remote-devices__device_bash':
        print('=====',m.group(1)); print(b[:9000])
