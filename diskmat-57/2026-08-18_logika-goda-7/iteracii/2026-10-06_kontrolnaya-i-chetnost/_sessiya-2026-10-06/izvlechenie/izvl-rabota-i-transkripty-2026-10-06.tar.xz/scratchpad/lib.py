import json, os
OUT='/mnt/user-data/outputs/izvl/out/E8.jsonl'
def _n():
    if not os.path.exists(OUT): return 0
    return sum(1 for _ in open(OUT,encoding='utf-8'))
class W:
    def __init__(self, src, kogda): self.src=src; self.kogda=kogda
    def src_(self, src, kogda=None):
        self.src=src
        if kogda: self.kogda=kogda
    def add(self, rows):
        n=_n(); out=[]
        for r in rows:
            n+=1
            vid,mesto,tekst=r[0],r[1],r[2]
            ex=r[3] if len(r)>3 else {}
            d={"id":f"E8-{n:03d}","kogda":ex.get('k',self.kogda),"istochnik":ex.get('s',self.src),"mesto":mesto,
               "kto":ex.get('kto','analitik'),"vid":vid,"tekst":tekst,"citata":ex.get('c',""),"pochemu":ex.get('p',""),"imya":ex.get('i',"")}
            if vid=='otvergnuto': assert d['pochemu'], (n,tekst)
            if vid=='chelovek': assert d['imya'], (n,tekst)
            if d['kto']=='vladelec': assert d['citata'], (n,tekst)
            out.append(json.dumps(d,ensure_ascii=False))
        with open(OUT,'a',encoding='utf-8') as f: f.write('\n'.join(out)+'\n')
        print('added',len(out),'total',_n())
