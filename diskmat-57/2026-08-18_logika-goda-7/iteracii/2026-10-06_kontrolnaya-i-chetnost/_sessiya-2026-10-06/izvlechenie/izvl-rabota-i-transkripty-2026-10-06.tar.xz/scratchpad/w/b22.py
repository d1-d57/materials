from L import add
S='транскрипт Claude Code 5fe2baf6 (резюме контекста: «Standing hard rules»)'
M='резюме контекста транскрипта, блок постоянных правил'
R=[
('2026-10-06 11:31',M,'vladelec','zapret','Постоянное жёсткое правило владельца про git: сам git он не трогает и никогда не просит его трогать; ему нельзя выдавать команды git, rm, find, xargs, глобы, && для запуска; единственная дверь — git_zona.py; любая операция git идёт пунктом в брифе исполнителя, а не строкой для владельца; git status не «только чтение».','GIT — I never touch git, and you never ask me to. Never hand me `git`, `rm`, `find`, `xargs`, globs, or `&&` to run… The only door is `git_zona.py`… Any git operation ships as an item inside an executor\'s brief, never as a line for me. `git status` is not read-only.','','',S),
('2026-10-06 11:31',M,'vladelec','trebovanie','Постоянное правило владельца про дневник: запись ведётся по ходу дела, а не задним числом; временные метки брать из `date`.','DIARY — written as it happens… Take timestamps from `date`.','','',S),
('2026-10-06 11:31',M,'vladelec','trebovanie','Постоянное правило владельца про интервью: каждая нетривиальная задача начинается с вопросов (интервью).','INTERVIEW — every non-trivial task starts with questions.','','',S),
('2026-10-06 11:31',M,'vladelec','zapret','Секреты владелец вводит сам через команду keychain и никогда не вставляет их в чат (значения секретов не выписываются).','','','',S),
]
add(R)
