import json,re
r=json.load(open('res.json'))
U=open('/mnt/user-data/uploads/materials/diskmat-57/2026-08-18_logika-goda-7/UROKI-FABRIKE.md',encoding='utf-8').read().split('\n')
def uroki_entries(kuda):
    out=[]
    for ts in re.findall(r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2})',kuda):
        for i,l in enumerate(U):
            if l.startswith('- '+ts):
                j=i+1; buf=[l]
                while j<len(U) and U[j].strip() and not U[j].startswith('- ') and not U[j].startswith('#'): buf.append(U[j]); j+=1
                out.append(' '.join(buf))
    for ts in re.findall(r'(\d{2}:\d{2})',kuda):
        pass
    m=re.search(r'### (\d+)\.',kuda)
    if m:
        for i,l in enumerate(U):
            if l.startswith('### %s.'%m.group(1)):
                out.append(' '.join(U[i:i+25]))
    return out
sq=lambda s: re.sub(r'\s+',' ',s)
for i,x in enumerate([x for x in r if x['K']=='K6']):
    print('=== #%d %s [%s/%s %s] cov=%s miss=%s'%(i,x['id'],x['vid'],x['kto'],x['kogda'],x['cov'],x['missnum']))
    print('K:',sq(x['kuda'])[:200]); print('M:',' '.join(x['missw_t']))
    print('T:',x['tekst'])
    if x['citata']: print('C:',sq(x['citata'])[:350])
    if x['pochemu']: print('P:',x['pochemu'][:200])
    if 'UROKI' in x['kuda']:
        es=uroki_entries(x['kuda'])
        # also date-only like '2026-10-05 01:10, 01:20' list
        for e in es[:3]: print('  U:',sq(e)[:700])
        if not es:
            for s,c in x['best'][:2]: print('  H%d:'%s,sq(c)[:300])
    else:
        for s,c in x['best'][:2]: print('  H%d:'%s,sq(c)[:300])
    for n,rec in x['svod'][:1]: print('  S[%s]:'%n[:10],sq(rec)[:200])
