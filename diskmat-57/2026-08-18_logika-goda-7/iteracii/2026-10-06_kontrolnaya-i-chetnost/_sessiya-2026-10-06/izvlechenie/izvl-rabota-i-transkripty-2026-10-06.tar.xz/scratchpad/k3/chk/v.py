from itertools import product, combinations, permutations
from math import gcd
R={}
def ok(k,got,exp): R[k]=(got==exp,got,exp)
ds=lambda n: sum(map(int,str(n)))
def parts(n,mx=None,cnt=None):
    mx=mx or n
    if n==0: yield (); return
    for k in range(min(n,mx),0,-1):
        for r in parts(n-k,k): yield (k,)+r
P=lambda n,**kw: list(parts(n))
def tri(sticks,mx=None):
    return [t for t in combinations(sorted(sticks),3) if t[0]+t[1]>t[2] and (mx is None or t[2]==mx)]
def coins(S,cs=(1,2,5)):
    c=0
    def go(s,i):
        nonlocal c
        if i==len(cs): c+= (s==0); return
        for k in range(s//cs[i]+1): go(s-k*cs[i],i+1)
    go(S,0); return c
def flags(k,cols='БКС'): return [''.join(f) for f in product(cols,repeat=k) if all(f[i]!=f[i+1] for i in range(k-1))]
cnt=lambda a,b,f: sum(1 for n in range(a,b+1) if f(n))
# ДЗ 29.09
ok('dz29-1',30-5-(18+15-(30-5))==0 and 18+15-25,8)
sq=lambda m,n: sum((m-k+1)*(n-k+1) for k in range(1,min(m,n)+1))
ok('dz29-2',sq(3,3),14); ok('dz29-3',len(tri(range(1,10))),34); ok('dz29-4',len(P(8)),22)
# КР 29.09
ok('kr29-1A',(214-87+1)//2,64); ok('kr29-1B',(232-95+1)//2,69)
ok('kr29-2A',(500//7,500//11,500-cnt(1,500,lambda n:n%7==0 or n%11==0)),(71,45,390))
ok('kr29-2B',(600//7,600//13,600-cnt(1,600,lambda n:n%7==0 or n%13==0)),(85,46,475))
ok('kr29-3A',(sq(3,6),3*5+2*6),(32,27)); ok('kr29-3B',(sq(4,5),4*4+3*5),(40,31))
ok('kr29-4A',(len(tri(range(1,8),7)),len(tri(range(1,8)))),(6,13)); ok('kr29-4B',(len(tri([1,2,4,5,6,7,8],8)),len(tri([1,2,4,5,6,7,8]))),(7,14))
# ДЗ к 6.10
ok('dz6-3',101-22-29,50); ok('dz6-4',cnt(10,99,lambda n: ds(n) in (2,3,5,7,11,13,17)),33)
ok('dz6-5',cnt(100,999,lambda n:n%9==0 or n%15==0),140); ok('dz6-5x',(cnt(100,999,lambda n:n%45==0),cnt(100,999,lambda n:n%135==0)),(20,7))
ok('dz6-6',cnt(100,999,lambda n:(int(str(n)[0])-int(str(n)[1]))%2==1 and ds(n)%10==0),45)
# кандидаты, ITOGI
ok('c-17-34',34-17+1,18); ok('c-ev18-96',cnt(18,96,lambda n:n%2==0),40); ok('c-ds4',cnt(100,999,lambda n:ds(n)==4),10)
ok('c-9rub',coins(9),8); ok('c-6rub',coins(6),5); ok('c-8rub',coins(8),7); ok('c-4or6',cnt(1,100,lambda n:n%4==0 or n%6==0),33)
ok('c-vag',11-3+1,9); ok('c-stolb12',13,13); ok('c-ev20-80',cnt(20,80,lambda n:n%2==0),31); ok('c-pg',112-45+1,68)
# лист верха
ok('v-10le3',len([p for p in P(10) if max(p)<=3]),14)
ok('v-tri',[len(tri(range(1,n+1))) for n in range(4,11)],[1,3,7,13,22,34,50])
ok('v-387',(738-387+1)//2,176); ok('v-357',cnt(1,1000,lambda n:n%3 and n%5 and n%7),457); ok('v-20rub',coins(20),29)
ok('v-AABV',len(set(permutations('ААБВ'))),12)
# базовая КР черновик + v1
ok('b-6',len(P(6)),11); ok('b-tri6',len(tri(range(1,7),6)),4); ok('b-gt37',cnt(38,99,lambda n:1),62); ok('b-25',15+12-(25-4),6)
ok('v1-123',len([n for n in product('123',repeat=3) if n[0]!=n[1] and n[1]!=n[2]]),12)
ok('v1-ev24-86',cnt(24,86,lambda n:n%2==0),32); ok('v1-6or9',cnt(1,100,lambda n:n%6==0 or n%9==0),22)
ok('v1-tri7B',len(tri([2,3,5,6,7],7)),4); ok('v1-lt58',cnt(10,57,lambda n:1),48); ok('v1-30',18+16-25,9)
ok('v1-12',coins(12),13); ok('v1-13',coins(13),14)
vas=lambda S: sum((S-5*f)//2 for f in range(S//5+1))
ok('R3',[(vas(S),coins(S)) for S in (10,11,12,13,15,20)],[(7,10),(8,11),(10,13),(11,14),(14,18),(24,29)])
# банк
ok('T-ds4-2',cnt(10,99,lambda n:ds(n)==4),4); ok('T-ds6',cnt(10,99,lambda n:ds(n)==6),6); ok('T-ds7',cnt(10,99,lambda n:ds(n)==7),7)
ok('T-5',len(P(5)),7); ok('T-7',len(P(7)),15); ok('T-9',len(P(9)),30)
ok('T-9in3',len([p for p in P(9) if len(p)==3]),7); ok('T-10in4',len([p for p in P(10) if len(p)==4]),9)
ok('T-tri16',len(tri(range(1,7))),7); ok('T-tri5',len(tri(range(1,6),5)),2)
ok('T-fl3',len(flags(3)),12); ok('T-routes',(len(set(permutations('ППВВ'))),len(set(permutations('ПППВВ')))),(6,10))
ok('d7',cnt(10,99,lambda n:abs(int(str(n)[0])-int(str(n)[1]))==6),7)
# R-правила
ok('R2',cnt(10,99,lambda n:ds(n)==13),6); ok('R4',(len(tri(range(1,10),9)),sum(b-1-(9-b)+1 for b in range(5,9))),(12,16))
ok('R5',cnt(100,999,lambda n:'5' in str(n)),252); ok('R5l',cnt(10,99,lambda n:'7' in str(n)),18)
ok('R6',sorted(n for n in range(100,1000) if ds(n)==4)[4],202)
def neck(n):  # карандаш: раскраски с точностью до переворота
    return len({min(c,c[::-1]) for c in product('КС',repeat=n)})
ok('R8',(neck(3),neck(4),neck(5)),(6,10,20))
ok('R9',len({min(c[i:]+c[:i] for i in range(4)) for c in product('01',repeat=4)}),6)
ok('R10',(7,15),(2**3-1,2**4-1))
ok('R11',(sum(1 for a in range(1,7) for b in range(1,7) if a+b==9),sum(1 for a in range(1,7) for b in range(1,7) if a+b==10)),(4,3))
ok('R12',len({sum(s) for k in range(1,5) for s in combinations((1,2,3,5),k)}),11)
ok('R13',cnt(100,999,lambda n:n%7==0),128)
ok('R14',sum(1 for p in permutations(range(4))),24)
# лента
ok('L-sum5',cnt(100,999,lambda n:ds(n)==5),15); ok('L-36-91',46-18+1,29); ok('L-key7',sum(str(n).count('7') for n in range(10,100)),19)
ok('L-masha',5+8-1,12); ok('L-split6',sum(sum(1 for p in P(6) if k in p) for k in range(1,7)),19)
ok('L-9num',(sorted(P(9),reverse=True).index((4,3,2))+1, sorted(P(9),reverse=True)[19]),(14,(3,3,2,1)))
ok('L-6num',(sorted(P(6),reverse=True).index((3,2,1))+1, sorted(P(6),reverse=True)[8]),(6,(2,2,1,1)))
# КР финал
ok('K1',(7+12-1,18-3+1,6+15-1,20-4+1),(18,16,20,17))
ok('K2',(cnt(17,52,lambda n:n%2==0),cnt(17,52,lambda n:n%3==0),cnt(23,64,lambda n:n%2==0),cnt(23,64,lambda n:n%3==0)),(18,12,21,14))
ok('K3',(28-5,28-5-9-6,30-4,30-4-11-7),(23,8,26,8))
ok('K4',(len([p for p in P(7) if max(p)<=3]),len([p for p in P(8) if max(p)<=3])),(8,10))
F=sorted(flags(4),key=lambda s:['БКС'.index(c) for c in s])
ok('K5',(F[F.index('БКСК')+1],F[F.index('КБКБ')-1],sum(f[0]=='Б' for f in F),F[F.index('БСБС')+1],F[F.index('СБКБ')-1],sum(f[0]=='К' for f in F)),('БСБК','БСКС',8,'БСКБ','КСКС',8))
ok('K6',(vas(12),coins(12),vas(13),coins(13)),(10,13,11,14))
ok('K7',(cnt(100,999,lambda n:ds(n)==6 and '0' in str(n)),cnt(100,999,lambda n:ds(n)==7 and '0' in str(n))),(11,13))
ok('K8',((71+10)//3,(74+10)//3),(27,28))
ok('K9',(cnt(1,1000,lambda n:n%6 and n%10 and n%15),cnt(1,1000,lambda n:n%6 and n%14 and n%21)),(734,762))
ok('K10',(len([f for f in flags(4) if f[0]!=f[-1]]),len([f for f in flags(5) if f[0]!=f[-1]])),(18,30))
inc=[n for n in range(100,1000) if str(n)[0]<str(n)[1]<str(n)[2]]
ok('K11',(inc[19],inc[inc.index(189)+1],inc[inc.index(345)-1],inc[29],inc[inc.index(289)+1],inc[inc.index(456)-1]),(157,234,289,235,345,389))
def kv(r,c):
    Pt={(i,j) for i in range(r) for j in range(c)};Q=set()
    for (x,y) in Pt:
        for (a,b) in Pt:
            dx,dy=a-x,b-y
            if (dx,dy)==(0,0): continue
            s=((x,y),(a,b),(a-dy,b+dx),(x-dy,y+dx))
            if all(q in Pt for q in s): Q.add(frozenset(s))
    return len(Q)
ok('K12',(kv(4,4),kv(4,5),kv(5,5)),(20,30,50))
# старые версии КР
ok('V-och',(75//3+1,84//3+1),(26,29)); ok('V-6-10',(cnt(1,1000,lambda n:n%6 and n%10),cnt(1,1000,lambda n:n%4 and n%6)),(767,667))
ok('V-B5',(coins(20,(1,2,5,10)),coins(21,(1,2,5,10))),(40,43))
def pol(n):
    c=0
    def rec(lo,hi):
        nonlocal c
        if hi-lo+1==n: c+=1; return
        if lo>0: rec(lo-1,hi)
        if hi<n-1: rec(lo,hi+1)
    for s in range(n): rec(s,s)
    return c
ok('V-pol',(pol(8),pol(9)),(128,256))
# мини-листок финал
ok('M1',(len([p for p in P(10) if len(p)==3]),len([p for p in P(11) if len(p)==3])),(8,10))
def pages(D):
    s=0
    for n in range(1,10000):
        s+=len(str(n))
        if s==D: return n
ok('M2',(pages(300),pages(270)),(136,126))
ok('M3',(sum(1 for f in flags(4) if f.count('Б')==1),sum(1 for f in flags(4) if f.count('С')==1),sum(1 for f in flags(3) if f.count('Б')==1)),(12,12,8))
ok('M4',(cnt(1,200,lambda n:n%4 and n%6),cnt(1,300,lambda n:n%4 and n%6)),(133,200))
ok('M5',(sum(a+b for a in range(7) for b in range(a,7)),sum(a+b for a in range(6) for b in range(a,6)),sum(a+b for a in range(10) for b in range(a,10))),(168,105,495))
def smeny(tab):
    T=[f'{h:02d}{m:02d}' for h in (range(24) if tab==24 else range(1,13)) for m in range(60)]
    return sum(sum(x!=y for x,y in zip(T[i],T[(i+1)%len(T)])) for i in range(len(T)))
ok('M6',(smeny(24),smeny(12)),(1611,806))
# мини-листок отвергнутые
ok('ml-masha',(cnt(100,999,lambda n:ds(n)==8),cnt(100,999,lambda n:ds(n)==9)),(36,45))
ok('ml-12',(cnt(100,999,lambda n:'1' in str(n) and '2' in str(n)),cnt(100,999,lambda n:'0' in str(n) and '5' in str(n))),(52,35))
ok('ml-strip',(8*9//2,9*10//2),(36,45))
def vfl(cols): 
    F=flags(3,cols); return len({min(f,f[::-1]) for f in F})
ok('ml-vfl',(vfl('БКС'),vfl('БКСЗ')),(9,24))
fib=[1,1]
for i in range(12): fib.append(fib[-1]+fib[-2])
ok('ml-kuz',(fib[8],fib[9]),(34,55))
ok('ml-even',(cnt(100,999,lambda n:ds(n)%2==0),cnt(1000,9999,lambda n:ds(n)%2==0)),(450,4500))
ok('ml-duty',(15,21),(6*5//2,7*6//2))
# кандидаты гроб/листок 6
def kings(n):
    c=0
    for a in range(n*n):
        for b in range(n*n):
            if a==b: continue
            if max(abs(a//n-b//n),abs(a%n-b%n))>1: c+=1
    return c
ok('kings',(kings(8),kings(7),kings(6)),(3612,2040,1040))
diag=lambda m,n: m+n-gcd(m,n)
ok('diag',(diag(60,36),diag(48,30),diag(20,12),diag(5,8),diag(4,6),diag(199,991),diag(100,101),diag(3,2)),(84,72,28,12,8,1189,200,4))
def sqsum(r,c): return sum(sum(1 for k in range(1,min(r,c)+1) for i in range(r-k+1) for j in range(c-k+1) if i<=x<i+k and j<=y<j+k) for x in range(r) for y in range(c))
ok('sqsum',(sqsum(4,4),sqsum(3,5)),(104,74))
def tritri(n):
    up=sum((n-k+1)*(n-k+2)//2 for k in range(1,n+1)); dn=sum((n-2*k+1)*(n-2*k+2)//2 for k in range(1,n//2+1)); return up+dn
ok('tritri',(tritri(4),tritri(5)),(27,48))
def pal(H,lead=True):
    c=0
    for h in range(H):
        for m in range(60):
            s=f'{h:02d}{m:02d}'
            if s==s[::-1]: c+=1
    return c
ok('pal',(pal(24),pal(30),pal(37)),(16,18,24))
pal12=sum(1 for h in range(1,13) for m in range(60) if (str(h)+f'{m:02d}')==(str(h)+f'{m:02d}')[::-1])
ok('pal12',pal12,57)
def per(P_):
    return sum(1 for a in range(1,P_) for b in range(a,P_) for c in range(b,P_) if a+b+c==P_ and a+b>c)
ok('perim',[per(p) for p in range(3,19)],[1,0,1,1,2,1,3,2,4,3,5,4,7,5,8,7])
ok('bul',(cnt(1,100,lambda n:n%7==0 or '7' in str(n)),cnt(1,50,lambda n:n%7==0 or '7' in str(n))),(30,11))
ok('sqcub',(cnt(1,1000,lambda n:round(n**.5)**2==n or round(n**(1/3))**3==n),),(38,))
ok('rect',(len([a for a in range(1,999) if a<=998-a]),len([a for a in range(1,1000) if a<=999-a]),len([a for a in range(1,10) if a<=10-a]),len([a for a in range(1,11) if a<=11-a])),(499,499,5,5))
ok('dice',[sum(1 for a in range(1,7) for b in range(1,7) if a+b==s) for s in range(2,13)],[1,2,3,4,5,6,5,4,3,2,1])
def weigh(ws):
    S=set()
    for c in product((-1,0,1),repeat=len(ws)):
        v=sum(a*b for a,b in zip(c,ws))
        if v>0: S.add(v)
    return sorted(S)
ok('gir',(weigh((1,3,9))==list(range(1,14)),weigh((1,3,9,27))==list(range(1,41))),(True,True))
ok('tour',36,37-1)
mins5=sum(1 for h in range(24) for m in range(60) if '5' in f'{h:02d}{m:02d}')
ok('min5',mins5,450)
ok('trains',len(range(-7,8)),15)
ok('kubki',None,None)
for k,v in R.items():
    if not v[0]: print('FAIL',k,v)
print(len(R),'checks;', sum(v[0] for v in R.values()),'ok')
