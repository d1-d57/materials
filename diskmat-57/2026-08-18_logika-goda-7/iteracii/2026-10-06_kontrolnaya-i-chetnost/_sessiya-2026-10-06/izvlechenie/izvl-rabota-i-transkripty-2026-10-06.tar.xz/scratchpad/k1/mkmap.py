import re, json
D='/mnt/user-data/outputs/izvl/dom/'
FN={'R':'K1-RESHENIYA-novye.md','P':'K1-PRINCIPY-PRIYOMA-dopolnenie.md','T':'K1-TREBOVANIYA-k-formatam.md'}
# locate ids per file with anchor
loc={}
for k,fn in FN.items():
    sec=''
    for line in open(D+fn):
        if line.startswith('#'): sec=line.strip('# \n')
        anchor=sec
        m=re.match(r'\| (Р\d+)',line)
        if m: anchor=m.group(1)
        m2=re.match(r'- (Р\d+):',line)
        if m2: anchor='Дополнения: '+m2.group(1)
        m3=re.match(r'\*\*(\d+)\.',line)
        if m3 and k=='P': anchor=sec+' п.'+m3.group(1)
        if k=='T': anchor=sec.split('.')[0]
        for i in re.findall(r'E\d-\d{3}',line):
            loc.setdefault(i,{}).setdefault(k,[])
            if anchor not in loc[i][k]: loc[i][k].append(anchor)
ids=[json.loads(l)['id'] for l in open('/mnt/user-data/outputs/izvl/vhod/K1.jsonl')]
M={}
for l in open('all.txt'):
    a=l.rstrip('\n').split('\t'); M[a[0]]=a
out=[]; problems=[]
for i in ids:
    _,ish,kuda=M[i]
    L=loc.get(i,{})
    def refs(skip=None):
        r=[]
        for k in 'RPT':
            if k==skip: continue
            if k in L: r.append(FN[k]+' '+', '.join(L[k]))
        return r
    if ish=='N':
        if not L: problems.append(('novoe-not-found',i,kuda)); 
        prim = 'R' if kuda[:2] not in ('pr','T:') else ('P' if kuda.startswith('pr') else 'T')
        if prim not in L: problems.append(('prim-missing',i,kuda,list(L)))
        k2=FN[prim]+' '+', '.join(L.get(prim,['?']))
        extra=refs(prim)
        out.append((i,'novoe','; '.join([k2]+['+ '+e for e in extra])))
    elif ish=='est':
        extra=refs()
        out.append((i,'est','; '.join([kuda]+['+ '+e for e in extra])))
    elif ish=='dubl':
        out.append((i,'dubl',kuda+(' ; '+'; '.join('+ '+e for e in refs()) if refs() else '')))
    else:
        out.append((i,ish,kuda))
with open(D+'map-K1.tsv','w') as f:
    for r in out: f.write('\t'.join(r)+'\n')
print(len(out)); print(problems)
import collections; print(collections.Counter(r[1] for r in out))
# ids in docs not in input
allin=set(ids); print('foreign', [i for i in loc if i not in allin])
