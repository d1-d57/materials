import json
OUT='/mnt/user-data/outputs/izvl/out/E5.jsonl'
JS='4180-repliki-vladelca-2026-10-06.jsonl'
SS='SESSIYA.md'
def n():
    try: return sum(1 for _ in open(OUT,encoding='utf-8'))
    except FileNotFoundError: return 0
def add(rows):
    k=n()
    with open(OUT,'a',encoding='utf-8') as f:
        for r in rows:
            k+=1
            kogda,ist,mesto,kto,vid,tekst,citata=r[:7]
            d={"id":"E5-%03d"%k,"kogda":kogda,"istochnik":ist,"mesto":mesto,"kto":kto,"vid":vid,"tekst":tekst,"citata":citata}
            if len(r)>7 and r[7]: d["pochemu"]=r[7]
            if len(r)>8 and r[8]: d["imya"]=r[8]
            f.write(json.dumps(d,ensure_ascii=False)+"\n")

_p='/mnt/user-data/uploads/materials/diskmat-57/2026-08-18_logika-goda-7/SESSIYA.md'
_L=open(_p,encoding='utf-8').read().split('\n')
SESS='\n'.join(_L[3251:])
def q(start,end=None,after=None):
    i0=0
    if after:
        i0=SESS.index(after)
    i=SESS.index(start,i0)
    if end is None: return start
    j=SESS.index(end,i)+len(end)
    return SESS[i:j]
