exec(open('load.py').read())
import json,sys
S=json.load(open('sample.json'))
def record(doc,i):
    t=DOM[doc]; L=t.split('\n')
    hits=[n for n,l in enumerate(L) if re.search(re.escape(i)+r'(?!\d)',l)]
    outs=[]
    for n in hits[:2]:
        l=L[n]
        if l.lstrip().startswith('|'): outs.append(l); continue
        a=n
        while a>0 and L[a-1].strip() and not L[a].lstrip().startswith('#') and not re.match(r'\s*[-*] |\s*\d+\. ',L[a]): a-=1
        b=n
        while b+1<len(L) and L[b+1].strip() and not L[b+1].lstrip().startswith('#') and not re.match(r'\s*[-*] ',L[b+1]): b+=1
        # for K3 style records spanning many lines (no list markers) go up to heading
        if doc.startswith('K3') or doc.startswith('K4b'):
            a2=n
            while a2>0 and not L[a2].startswith('#'): a2-=1
            if n-a2<40: a=a2
        outs.append('\n'.join(L[a:b+1]))
    return outs
def lcs_frac(c,r):
    c=norm(c).lower(); r=norm(r).lower()
    if not c: return None
    if c in r: return 1.0
    # longest substring of c in r
    best=0
    for w in range(len(c),9,-1):
        found=False
        for s in range(0,len(c)-w+1, max(1,w//4)):
            if c[s:s+w] in r: found=True;break
        if found: best=w;break
    return round(best/len(c),2)
def qcheck(cit,rec):
    qs=re.findall(r'«([^«»]{8,})»',rec)
    c=norm(cit).lower()
    res=[]
    for q in qs:
        res.append((q[:60], norm(q).lower().strip(' .,…') in c))
    return res

