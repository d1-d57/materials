import sys,re,html
t=html.unescape(open(sys.argv[1],encoding='utf-8').read())
maxc=int(sys.argv[2]) if len(sys.argv)>2 else 600
# split tool blocks
out=[]
pos=0
for m in re.finditer(r'<tool name="([^"]+)">(.*?)</tool>',t,flags=re.S):
    out.append(t[pos:m.start()])
    name=m.group(1); body=m.group(2)
    if name in('Write','Edit','AskUserQuestion','SendUserMessage','mcp__widgets__x'):
        out.append(f'<<{name}: {body}>>' )
    else:
        out.append(f'<<{name} {body[:maxc].replace(chr(10)," ")}>>')
    pos=m.end()
out.append(t[pos:])
print(''.join(out))
