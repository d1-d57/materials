exec(open('load.py').read())
import collections
K=sys.argv[1]
G=collections.OrderedDict()
for k,i,t in EST:
    if k!=K: continue
    G.setdefault(t,[]).append(i)
# group by primary R number
def rk(t):
    m=re.findall(r'Р(\d+)',t); return (int(m[0]) if m else 9999, t)
out=[]
shown=set()
for t in sorted(G,key=rk):
    rs=re.findall(r'Р\d+',t)
    out.append('#'*20+' TARGET: '+t)
    for r in rs:
        if r in shown: out.append(f'[{r} shown above]'); continue
        shown.add(r); out.append(R.get(r,'!!! NO ROW '+r).strip())
    for i in G[t]:
        u=U[i]
        inn=[n for n,txt in DOM.items() if re.search(re.escape(i)+r'(?!\d)',txt)]
        out.append(f"  -- {i} [{u['kto']}/{u['vid']} {u['kogda']}] dom={inn}\n     T: {u['tekst']}\n     C: {u.get('citata','')}\n     P: {u.get('pochemu','')}")
open(f'dump-{K}.txt','w').write('\n'.join(out))
print(len('\n'.join(out)))
