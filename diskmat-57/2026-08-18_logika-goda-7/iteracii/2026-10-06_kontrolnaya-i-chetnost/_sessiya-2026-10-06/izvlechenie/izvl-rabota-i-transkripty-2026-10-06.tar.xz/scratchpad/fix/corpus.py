import json,re,glob,sys
D='/mnt/user-data/uploads/materials/diskmat-57/2026-08-18_logika-goda-7'
def txt_jsonl_user(p):
    out=[]
    for l in open(p,encoding='utf-8'):
        try: d=json.loads(l)
        except: continue
        if d.get('type')!='user': continue
        m=d.get('message',{}); c=m.get('content')
        if isinstance(c,str): out.append(c)
        elif isinstance(c,list):
            for b in c:
                if isinstance(b,dict) and b.get('type')=='text': out.append(b['text'])
    return '\n'.join(out)
PRIMARY={
 'OTVETY-05':open(D+'/OTVETY-vladelca-2026-10-05.txt',encoding='utf-8').read(),
 'OTVETY-04':open(D+'/OTVETY-vladelca-2026-10-04.txt',encoding='utf-8').read(),
 'SESSIYA':open(D+'/SESSIYA.md',encoding='utf-8').read(),
 '4180':txt_jsonl_user('/mnt/user-data/outputs/handoff1006/sess/4180-repliki-vladelca-2026-10-06.jsonl'),
}
SECOND={
 'trx-10-05(user)':txt_jsonl_user(D+'/iteracii/2026-09-29_kombinatorika-2/_trash/transkript-2026-09-29_10-05.jsonl'),
 'repliki1006':'\n'.join(open(f,encoding='utf-8').read() for f in sorted(glob.glob('/mnt/user-data/outputs/handoff1006/repliki/*.txt')) if 'vidzhet' not in f),
}
def norm(s):
    s=s.replace(' ',' ').replace('ё','е').replace('Ё','Е')
    s=s.replace('<unk>','')
    s=re.sub(r'[«»“”„"]','',s); s=re.sub(r'[—–‑-]','-',s).replace('’',"'")
    s=s.lower()
    return re.sub(r'\s+',' ',s).strip()
NP={k:norm(v) for k,v in PRIMARY.items()}
NS={k:norm(v) for k,v in SECOND.items()}
def where(frag):
    f=norm(frag)
    a=[k for k,v in NP.items() if f in v]
    b=[k for k,v in NS.items() if f in v]
    return a,b
def pieces(q):
    # split on ellipsis
    return [p.strip(' ,.;:!?"«»') for p in re.split(r'…|\.\.\.|\[…\]',q) if len(p.strip(' ,.;:!?"«»'))>=4]
def quotes(text):
    # top-level «» with nesting
    res=[];depth=0;start=None
    for i,ch in enumerate(text):
        if ch=='«':
            if depth==0: start=i
            depth+=1
        elif ch=='»' and depth>0:
            depth-=1
            if depth==0: res.append((start,text[start+1:i]))
    return res
