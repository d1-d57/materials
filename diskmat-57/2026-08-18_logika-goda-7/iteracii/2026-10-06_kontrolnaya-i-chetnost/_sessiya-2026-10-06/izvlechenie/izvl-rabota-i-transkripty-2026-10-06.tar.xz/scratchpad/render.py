from playwright.sync_api import sync_playwright
import pathlib
html="<html><body style='background:#fff;margin:10px'>"
for f in ["fig1.svg","fig2.svg","fig3.svg"]:
    s=pathlib.Path(f).read_text(encoding='utf-8').replace('<svg ','<svg xmlns="http://www.w3.org/2000/svg" width="900" ',1)
    html+=f"<div style='border:1px dashed #f00;display:inline-block;margin:6px'>{s}</div><br>"
html+="</body></html>"
pathlib.Path("figs.html").write_text(html,encoding='utf-8')
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={"width":960,"height":1200})
    pg.goto("file://"+str(pathlib.Path("figs.html").resolve())); pg.screenshot(path="figs.png",full_page=True)
    # bounding boxes of the 'первая' label and row label 5
    bb=pg.evaluate("""()=>{const r=[];document.querySelectorAll('svg')[0].querySelectorAll('text').forEach(t=>{if(['первая','5','4','6'].includes(t.textContent)&&t.getAttribute('x')<30){const b=t.getBBox();r.push([t.textContent,b.x.toFixed(1),b.y.toFixed(1),b.width.toFixed(1),b.height.toFixed(1)])}});return r}""")
    print(bb)
    b.close()
