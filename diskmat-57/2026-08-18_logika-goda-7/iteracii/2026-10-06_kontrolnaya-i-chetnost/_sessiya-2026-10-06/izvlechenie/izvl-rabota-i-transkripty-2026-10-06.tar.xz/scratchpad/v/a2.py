exec(open('a.py').read().split("k=sys.argv[1]")[0])
def record(doc,i):
    L=DOM[doc].split('\n'); outs=[]
    for n,l in enumerate(L):
        if not re.search(re.escape(i)+r'(?!\d)',l): continue
        a=n
        while a>0 and not re.match(r'\s*([-*] |#|\|)',L[a]) and L[a-1].strip(): a-=1
        b=n
        while b+1<len(L) and L[b+1].strip() and not re.match(r'\s*([-*] |#|\|)',L[b+1]): b+=1
        outs.append('\n'.join(L[a:b+1]))
        if len(outs)>=2: break
    return outs
k=sys.argv[1]; sec=sys.argv[2] if len(sys.argv)>2 else 'A'
for i in S[sec][k]:
    u=U[i]; kk,ish,kuda=M[i][0]
    docs=[d for d in DOM if d in kuda] or [d for d in DOM if d.startswith(k+'-')]
    print('='*8,i,'|',kuda)
    print('UNIT kto=%s vid=%s imya=%s'%(u['kto'],u['vid'],u.get('imya','')))
    print('  T:',u['tekst'])
    if u.get('citata'): print('  C:',u['citata'])
    if u.get('pochemu'): print('  P:',u['pochemu'])
    for d in docs:
        for r in record(d,i):
            r=r if len(r)<3000 else r[:3000]+' …[cut]'
            print('REC[%s]:'%d, r)
            if u['kto']=='vladelec': print('  cit-in-rec:',lcs_frac(u.get('citata',''),r))
