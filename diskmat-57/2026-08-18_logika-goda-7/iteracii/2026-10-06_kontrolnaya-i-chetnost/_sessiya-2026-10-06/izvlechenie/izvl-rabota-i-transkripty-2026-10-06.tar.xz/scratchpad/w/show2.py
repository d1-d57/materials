import json,sys,re
r=json.load(open('res.json'))
K=sys.argv[1]; lo=int(sys.argv[2]); hi=int(sys.argv[3])
xs=[x for x in r if x['K']==K][lo:hi]
sq=lambda s: re.sub(r'\s+',' ',s)
for i,x in enumerate(xs):
    print('=== #%d %s [%s/%s %s] cov=%s miss=%s'%(lo+i,x['id'],x['vid'],x['kto'],x['kogda'],x['cov'],x['missnum']))
    print('K:',sq(x['kuda'])[:200]); print('M:',' '.join(x['missw_t']))
    print('T:',x['tekst'])
    if x['citata']: print('C:',sq(x['citata'])[:350])
    if x['pochemu']: print('P:',x['pochemu'][:200])
    for n,rec in x['svod'][:1]: print('S[%s]:'%n[:8],sq(rec)[:220])
    for s,c in x['best'][:2]: print('  H%d:'%s,sq(c)[:260])
