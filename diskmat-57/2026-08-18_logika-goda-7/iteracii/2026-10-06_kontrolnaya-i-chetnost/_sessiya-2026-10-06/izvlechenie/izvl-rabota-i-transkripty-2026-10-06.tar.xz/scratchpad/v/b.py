exec(open("common.py").read())
import glob,html
ROOT='/mnt/user-data/uploads/materials/diskmat-57/'
RES=open(ROOT+'docs/RESHENIYA.md',encoding='utf-8').read().split('\n')
def rrow(n):
    for l in RES:
        if re.match(r'\|\s*Р%s\s*[ (|]'%n,l): return l
    return None
files={}
for f in glob.glob(ROOT+'**/*',recursive=True):
    if os.path.isfile(f) and f.endswith(('.md','.txt','.html')):
        files[f]=None
def ftext(f):
    if files.get(f) is None:
        t=open(f,encoding='utf-8',errors='ignore').read()
        if f.endswith('.html'): t=html.unescape(re.sub(r'<[^>]+>',' ',t))
        files[f]=t
    return files[f]
def resolve(kuda):
    out=[]
    for fn in re.findall(r'([A-Za-z0-9_\-\.]+\.(?:md|txt|html))',kuda):
        if fn.startswith(('K1-','K2-','K3-','K4','K5-','K6-')): continue
        c=[f for f in files if f.endswith('/'+fn)]
        out.append((fn,c))
    for d in re.findall(r'ITOGI-2026-10-05/(0\d)',kuda):
        c=[f for f in files if '/ITOGI-2026-10-05/'+d in f]; out.append(('ITOGI/'+d,c))
    if re.search(r'\bSESSIYA\b',kuda): out.append(('SESSIYA',[ROOT+'2026-08-18_logika-goda-7/SESSIYA.md']))
    if re.search(r'\bNAVIGATOR\b',kuda) and not any(x[0]=='NAVIGATOR.md' for x in out): out.append(('NAVIGATOR',[ROOT+'2026-08-18_logika-goda-7/NAVIGATOR.md']))
    return out
STOP=set('это что как для при или его она они так уже нет тоже только если чтобы потом через после когда было будет надо можно есть всё все ещё один одна аналитик владелец'.split())
def kws(t):
    w=re.findall(r'[А-Яа-яЁёA-Za-z0-9]{5,}',t)
    w=[x for x in w if x.lower() not in STOP]
    # prefer rarer words: sort by length
    seen=[];[seen.append(x) for x in w if x not in seen]
    return sorted(seen,key=len,reverse=True)[:10]
k=sys.argv[1]
for i in S['B'][k]:
    u=U[i]; kuda=M[i][0][2]
    print('='*6,i,'|',kuda[:200]); print('  T:',u['tekst'][:400])
    if u.get('citata'): print('  C:',u['citata'][:200])
    for n in sorted(set(re.findall(r'Р(\d{1,3})',kuda)),key=int)[:4]:
        r=rrow(n); print('  Р%s:'%n,(r or 'НЕТ СТРОКИ')[:700])
    kw=kws(u['tekst'])
    for fn,c in resolve(kuda):
        if not c: print('  FILE',fn,'НЕТ В КОПИЯХ'); continue
        t=ftext(c[0]); L=t.split('\n')
        sc=[]
        for j,l in enumerate(L):
            s=sum(1 for w in kw if w.lower()[:7] in l.lower())
            if s: sc.append((s,j))
        sc.sort(reverse=True)
        print('  FILE',fn,'kw=',kw[:6])
        for s,j in sc[:2]: print('    [%d] L%d: %s'%(s,j+1,L[j][:400]))
