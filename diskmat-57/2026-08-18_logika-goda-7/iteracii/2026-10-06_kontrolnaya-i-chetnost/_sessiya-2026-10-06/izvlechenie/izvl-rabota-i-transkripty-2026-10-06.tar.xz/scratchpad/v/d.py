exec(open('load.py').read())
import json
S=json.load(open('sample.json'))
R='/mnt/user-data/uploads/materials/diskmat-57/2026-08-18_logika-goda-7/'
src2=open(R+'OTVETY-vladelca-2026-10-05.txt',encoding='utf-8').read()
j=[]
for l in open('/mnt/user-data/outputs/handoff1006/sess/4180-repliki-vladelca-2026-10-06.jsonl',encoding='utf-8'):
    try:
        d=json.loads(l); c=d['message']['content']
        if isinstance(c,list): c=' '.join(x.get('text','') for x in c if isinstance(x,dict))
        j.append(c)
    except Exception as e: pass
src5=' \n '.join(j)+'\n'+open(R+'SESSIYA.md',encoding='utf-8').read()
def chk(cit,src):
    n=norm(src).lower(); c=norm(cit).lower()
    if c in n: return 'FULL',[]
    fr=[norm(x).strip(' .,') for x in re.split(r'…|\.\.\.|\[\.\.\.\]|\[…\]',cit)]
    fr=[x for x in fr if len(x)>3]
    miss=[x for x in fr if x.lower() not in n]
    return ('FRAG' if not miss else 'FAIL'),miss
out=collections.Counter()
for e,src in [('E2',src2),('E5',src5)]:
    for i in S['D'][e]:
        u=U[i]; st,miss=chk(u.get('citata',''),src)
        out[(e,st)]+=1
        if st!='FULL': print(i,st,u.get('mesto'),'|',u.get('citata')[:300],'|| MISS:',[m[:150] for m in miss])
print(out)
print('--- full population')
c2=collections.Counter()
for e,src in [('E2',src2),('E5',src5)]:
    for i,u in U.items():
        if i.startswith(e+'-') and u['kto']=='vladelec':
            st,miss=chk(u.get('citata',''),src); c2[(e,st)]+=1
            if st!='FULL': print(i,st,'|',u.get('citata','')[:200],'|| MISS',[m[:120] for m in miss])
print(c2)
