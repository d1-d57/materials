import json,os
OUT='/mnt/user-data/outputs/izvl/out/E3.jsonl'
SRC='чат d89bb512 «Распознавание школьных работ»'
def add(rows):
    n=sum(1 for l in open(OUT,encoding='utf-8') if l.strip()) if os.path.exists(OUT) else 0
    with open(OUT,'a',encoding='utf-8') as f:
        for r in rows:
            r=tuple(r)+('',)*(8-len(r))
            n+=1
            d={"id":f"E3-{n:03d}","kogda":r[0],"istochnik":SRC,"mesto":r[1],"kto":r[2],"vid":r[3],"tekst":r[4],"citata":r[5],"pochemu":r[6]}
            if r[7]: d["imya"]=r[7]
            f.write(json.dumps(d,ensure_ascii=False)+"\n")
    print('total',n)
