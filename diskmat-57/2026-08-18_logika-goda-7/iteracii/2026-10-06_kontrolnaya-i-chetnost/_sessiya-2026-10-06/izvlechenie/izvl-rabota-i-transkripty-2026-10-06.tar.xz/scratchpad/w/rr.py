import sys,re
L=open('/mnt/user-data/uploads/materials/diskmat-57/docs/RESHENIYA.md',encoding='utf-8').read().split('\n')
for a in sys.argv[1:]:
    for l in L:
        if re.match(r'\|\s*Р%s\b'%a,l): print(l); print()
