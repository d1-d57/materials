import re, sys, html, os
OUT = "/mnt/user-data/outputs/handoff1006/repliki"
src = open(sys.argv[1], encoding="utf-8").read()

def prev_human(n):
    prev = sorted(f for f in os.listdir(OUT) if "vidzhet" not in f and int(f[:3]) < n)
    if not prev:
        return None, "XXXX-XX-XX", "XX", "XX", None
    pf = prev[-1]
    return int(pf[:3]), pf[4:14], pf[15:17], pf[17:19], pf

def diary_blocks(body):
    res = []
    for b in re.finditer(r"\n## '''\+T\+r?'''(.*?)'''", body, re.S):
        res.append(b.group(1))
    for b in re.finditer(r"printf '\\n## %s(.*?)' \"\$T\"", body, re.S):
        res.append(b.group(1).replace("\\n", "\n"))
    for b in re.finditer(r"<<'?EOF'?\n\n## \$T(.*?)\nEOF", body, re.S):
        res.append(b.group(1))
    return res

for m in re.finditer(r'<turn n="(\d+)">(.*?)</turn>', src, re.S):
    n = int(m.group(1)); body = html.unescape(m.group(2))
    if body.startswith("Human:"):
        t = body[len("Human:"):]
        ts = re.search(r"Message sent at \w+ (\d{4}-\d\d-\d\d) (\d\d):(\d\d) local time", t)
        text = re.sub(r"<system-reminder>.*?</system-reminder>", "", t, flags=re.S)
        text = text.lstrip("\n").lstrip(" ").rstrip()
        if not text.strip():
            print(f"turn {n}: human EMPTY; has-timestamp={bool(ts)} {ts.group(0) if ts else ''} rawlen={len(t)}")
            continue
        d, hh, mm = ts.groups() if ts else ("XXXX-XX-XX", "XX", "XX")
        fn = f"{OUT}/{n:03d}_{d}_{hh}{mm}.txt"
        with open(fn, "w", encoding="utf-8") as f:
            f.write(f"# ход {n} · {d} {hh}:{mm} МСК\n\n{text}\n")
        print(f"turn {n}: HUMAN written {os.path.basename(fn)} len={len(text)} ts={'ok' if ts else 'MISSING'}")
        print("   preview:", text[:200].replace("\n", " | "))
    else:
        asks = re.findall(r'<tool name="AskUserQuestion">\s*<parameter name="questions">(.*?)</parameter>', body, re.S)
        raw = len(re.findall(r"User has answered|The user answered|user answered", body, re.I))
        blocks = diary_blocks(body)
        print(f"turn {n}: assistant len={len(body)} AskUserQuestion={len(asks)} raw-answer-strings={raw} diary-blocks={len(blocks)}")
        for blk in blocks:
            print("   diary head:", blk.strip().split("\n", 1)[0][:200])
        wblocks = [b for b in blocks if re.search(r"виджет\b|\(виджет\)|\+ виджет", b)]
        ln, d, hh, mm, pf = prev_human(n)
        for i, blk in enumerate(wblocks):
            suf = "" if len(wblocks) == 1 else f"_{i+1}"
            fn = f"{OUT}/{n:03d}_{d}_{hh}{mm}_vidzhet{suf}.txt"
            verb = "дословно (по пометке ассистента)" if "дословно" in blk else "НЕ дословно — сводка ассистента"
            with open(fn, "w", encoding="utf-8") as f:
                f.write(f"# ход {n} (Assistant) · {d} {hh}:{mm} МСК · время приблизительно (по ходу человека {ln})\n"
                        f"# источник: запись ассистента в SESSIYA.md; сырой ответ виджета в read_conversation не виден; {verb}\n\n"
                        f"## <T>{blk.rstrip()}\n")
            print(f"   VIDZHET written {os.path.basename(fn)} len={len(blk)}")
        if asks and not wblocks:
            print("   (AskUserQuestion без записи ответов в дневнике в этом ходе)")
        for a in asks:
            print("   ASK:", a[:150].replace("\n", " "))
