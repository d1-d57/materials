import json, re, glob, os, sys, html
W = os.path.dirname(os.path.abspath(__file__))
IZ = '/mnt/user-data/outputs/izvl'
ROOT = '/mnt/user-data/uploads/materials/diskmat-57'
LG = ROOT + '/2026-08-18_logika-goda-7'
IT = LG + '/iteracii/2026-10-06_kontrolnaya-i-chetnost'
UNITS = {}
for f in sorted(glob.glob(IZ + '/out/E*.jsonl')):
    for line in open(f, encoding='utf-8'):
        line = line.strip()
        if line:
            u = json.loads(line); UNITS[u['id']] = u

def readf(p):
    t = open(p, encoding='utf-8', errors='replace').read()
    if p.endswith('.html'):
        t = re.sub(r'<script.*?</script>|<style.*?</style>', ' ', t, flags=re.S)
        t = html.unescape(re.sub(r'<[^>]+>', ' ', t))
    return t

CACHE = {}
def load(p):
    if p not in CACHE:
        CACHE[p] = readf(p) if os.path.exists(p) else None
    return CACHE[p]

RESH = load(ROOT + '/docs/RESHENIYA.md')
RROWS = {}
cur = None
for line in RESH.split('\n'):
    m = re.match(r'\|\s*Р(\d+)\b', line)
    if m:
        cur = int(m.group(1)); RROWS.setdefault(cur, ''); RROWS[cur] += line + '\n'
    elif cur is not None and line.strip() and not line.startswith('|') and not line.startswith('#'):
        RROWS[cur] += line + '\n'
    else:
        cur = None if not line.strip() or line.startswith('#') else cur

FILEKEYS = [
    ('RESHENIYA.md', None),
    ('LESTNICA-PEREBOR', IT + '/LESTNICA-PEREBOR.md'),
    ('KONCEPCIYA-6-10', IT + '/KONCEPCIYA-6-10.md'),
    ('BRAINSTORM-perebor', IT + '/BRAINSTORM-perebor.md'),
    ('KR-6-10-chernovik', IT + '/KR-6-10-chernovik.md'),
    ('TABLO', IT + '/TABLO.md'),
    ('VERIFY-ITOGI', IT + '/_sessiya-2026-10-05/VERIFY-ITOGI-2026-10-05.md'),
    ('RAZBOR-29-09', LG + '/iteracii/2026-09-29_kombinatorika-2/RAZBOR-29-09.md'),
    ('KLASTERY-29-09', LG + '/iteracii/2026-09-29_kombinatorika-2/KLASTERY-29-09.txt'),
    ('01-klass', LG + '/ITOGI-2026-10-05/01-klass.md'),
    ('02-odna-ideya', LG + '/ITOGI-2026-10-05/02-odna-ideya.md'),
    ('03-perebor', LG + '/ITOGI-2026-10-05/03-perebor-chto-izvestno.md'),
    ('04-idei-uroka', LG + '/ITOGI-2026-10-05/04-idei-uroka.md'),
    ('05-kontrolnaya', LG + '/ITOGI-2026-10-05/05-kontrolnaya.md'),
    ('06-bank', LG + '/ITOGI-2026-10-05/06-bank.md'),
    ('07-voprosy', LG + '/ITOGI-2026-10-05/07-voprosy.md'),
    ('ITOGI-2026-10-05.md', LG + '/ITOGI-2026-10-05.md'),
    ('UROKI-FABRIKE', LG + '/UROKI-FABRIKE.md'),
    ('FORMAT-listka', LG + '/FORMAT-listka-po-otvetu.md'),
    ('NAVIGATOR', LG + '/NAVIGATOR.md'),
    ('PLAN.md', LG + '/PLAN.md'),
    ('HANDOFF-2026-10-07', LG + '/HANDOFF-2026-10-07.md'),
    ('SPISOK-7I', LG + '/SPISOK-7I.txt'),
    ('publish-v1', None),
]
LENTA = [LG + '/iteracii/2026-10-06_kontrolnaya-i-chetnost/statya-urok-1/LENTA/publish-v16.html',
         LG + '/iteracii/2026-10-06_kontrolnaya-i-chetnost/statya-urok-1/LENTA/publish-v11.html',
         '/mnt/user-data/outputs/statya-urok-1/_sluzhebnoe/lenta-istochnik.md']

def targets(kuda):
    k = re.sub(r'\((свод|сводка|повтор)[^)]*\)', ' ', kuda)
    k = re.sub(r'свод K4b\S*', ' ', k)
    k = re.sub(r'K5-LYUDI-7I\.md[^;]*', ' ', k)
    parts = []  # (label, text)
    rs = set()
    for m in re.finditer(r'Р(\d+)\s*[–-]\s*Р(\d+)', k):
        rs.update(range(int(m.group(1)), int(m.group(2)) + 1))
    for m in re.finditer(r'Р(\d+)', k):
        rs.add(int(m.group(1)))
    for r in sorted(rs):
        if r in RROWS: parts.append(('Р%d' % r, RROWS[r]))
        else: parts.append(('Р%d?MISSING' % r, ''))
    fk = False
    for key, path in FILEKEYS:
        if key in k and path:
            if key == 'ITOGI-2026-10-05.md' and 'ITOGI-2026-10-05.md' not in k: continue
            parts.append((key, load(path) or '')); fk = True
    if 'шапки' in k and 'it610' in k:
        for key in ['KONCEPCIYA-6-10', 'LESTNICA-PEREBOR', 'KR-6-10-chernovik', 'BRAINSTORM-perebor']:
            p = dict(FILEKEYS)[key]
            if not any(x[0] == key for x in parts): parts.append((key, load(p)))
    if 'publish-v1' in k or 'LENTA' in k:
        for p in LENTA: parts.append((os.path.basename(p), load(p) or ''))
    return parts

STOP = set('этого этому этот также после через чтобы который которые которая можно нужно потому только когда будет более будут между всего всех своих своим него неё если есть было была были даже очень просто здесь ещё уже того тоже всем')
def norm(s):
    return s.lower().replace('ё', 'е')
def toks(s):
    s = norm(s)
    out = set()
    for w in re.findall(r'[a-zа-я]+|\d+(?:[.,]\d+)?', s):
        if w.isdigit() or re.match(r'\d', w):
            if len(w) >= 2 or True: out.add('#' + w)
        elif len(w) >= 5 and w not in STOP:
            out.add(w[:5])
    return out

def windows(text, size=6):
    lines = [l for l in text.split('\n')]
    # paragraph-ish windows of up to `size` lines
    res = []
    for i in range(0, len(lines)):
        chunk = '\n'.join(lines[i:i + size])
        if chunk.strip(): res.append(chunk)
    return res

def best(text, ut, n=2):
    sc = []
    lines = text.split('\n')
    for i in range(len(lines)):
        chunk = '\n'.join(lines[i:i + 4])
        ct = toks(chunk)
        s = len(ut & ct)
        sc.append((s, i, chunk))
    sc.sort(key=lambda x: -x[0])
    out = []; used = set()
    for s, i, c in sc:
        if any(abs(i - j) < 4 for j in used): continue
        used.add(i); out.append((s, c))
        if len(out) >= n: break
    return out

rows = [l.rstrip('\n').split('\t') for l in open(W + '/est.tsv', encoding='utf-8')]
res = []
for K, uid, kuda in rows:
    u = UNITS[uid]
    ut = toks(u.get('tekst', '') + ' ' + u.get('pochemu', '') + ' ' + u.get('imya', ''))
    ct = toks(u.get('citata', ''))
    parts = targets(kuda)
    corpus = '\n'.join(t or '' for _, t in parts)
    cT = toks(corpus)
    cov = len(ut & cT) / max(1, len(ut))
    nums = {t for t in ut | ct if t.startswith('#') and len(t) > 2}
    missnum = sorted(nums - cT)
    citcov = len(ct & cT) / max(1, len(ct)) if ct else None
    # citation substring presence (normalised)
    cit = u.get('citata', '')
    def nn(s): return re.sub(r'[\s«»"“”„\'—–\-….,:;!?()]+', ' ', norm(s)).strip()
    citin = None
    if cit and u.get('kto') == 'vladelec':
        nc = nn(cit); NC = nn(corpus)
        frag = nc[:60]
        citin = (frag in NC) if frag else None
    res.append(dict(K=K, id=uid, kuda=kuda, labels=[p[0] for p in parts], cov=round(cov, 2), citcov=citcov and round(citcov, 2),
                    citin=citin, missnum=missnum, kto=u.get('kto'), vid=u.get('vid'), kogda=u.get('kogda'),
                    tekst=u.get('tekst'), citata=cit, pochemu=u.get('pochemu', ''), imya=u.get('imya', ''),
                    best=[(s, c[:420]) for s, c in best(corpus, ut | ct)] if corpus.strip() else []))
json.dump(res, open(W + '/res.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
import collections
print(len(res), collections.Counter(r['K'] for r in res))
print('no-target', [r['id'] for r in res if not r['labels']])
print('missing R', [(r['id'], r['labels']) for r in res if any('MISSING' in l for l in r['labels'])])
