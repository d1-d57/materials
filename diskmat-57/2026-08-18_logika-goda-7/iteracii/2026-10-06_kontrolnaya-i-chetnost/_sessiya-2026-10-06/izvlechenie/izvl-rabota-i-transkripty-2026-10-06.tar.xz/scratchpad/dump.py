import json,sys
src=sys.argv[1]; out=sys.argv[2]
from datetime import datetime,timedelta
n=0
with open(src) as f, open(out,'w') as o:
    for i,line in enumerate(f):
        try: r=json.loads(line)
        except: continue
        ts=r.get('timestamp','')
        if not ts.startswith('2026-10-04'): continue
        t=r.get('type')
        msk=(datetime.fromisoformat(ts.replace('Z','+00:00'))+timedelta(hours=3)).strftime('%m-%d %H:%M')
        m=r.get('message',{})
        c=m.get('content') if isinstance(m,dict) else None
        parts=[]
        if t=='user':
            if isinstance(c,str): parts.append(c)
            elif isinstance(c,list):
                for b in c:
                    if b.get('type')=='text': parts.append(b['text'])
                    elif b.get('type')=='tool_result':
                        cc=b.get('content')
                        if isinstance(cc,list): cc=' '.join(x.get('text','') for x in cc if isinstance(x,dict))
                        if cc and ('user answered' in cc.lower() or 'user has answered' in cc.lower()): parts.append('[WIDGET] '+cc)
                        elif cc and len(cc)>0 and False: pass
        elif t=='assistant' and isinstance(c,list):
            for b in c:
                if b.get('type')=='text' and b['text'].strip(): parts.append(b['text'])
        for p in parts:
            o.write(f"\n=== L{i} {msk} {t} ===\n{p}\n"); n+=1
print(n)
