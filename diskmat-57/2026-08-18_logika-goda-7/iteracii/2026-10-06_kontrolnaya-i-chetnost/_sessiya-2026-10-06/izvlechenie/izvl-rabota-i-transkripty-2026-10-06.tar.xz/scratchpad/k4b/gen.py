import json, re, sys, collections
sys.path.insert(0, '/tmp/claude-0/-home-claude/5fe2baf6-90cb-5754-9096-9aab3efe6076/scratchpad/k4b')
from intro import TOPICS, STATUS
D = '/tmp/claude-0/-home-claude/5fe2baf6-90cb-5754-9096-9aab3efe6076/scratchpad/k4b/'
L = [json.loads(l) for l in open('/mnt/user-data/outputs/izvl/vhod/K4b.jsonl')]
U = {x['id']: x for x in L}
N = json.load(open(D + 'notes.json'))
# extra notes/edits (applied after review)
try:
    for l in open(D + 'edits.tsv'):
        if not l.strip() or l.startswith('#'): continue
        p = l.rstrip('\n').split('\t')
        while len(p) < 4: p.append('')
        old = N[p[0]]
        N[p[0]] = [p[0], p[1] or old[1], p[2] or old[2], ('' if p[3]=='~' else (p[3] if p[3] else old[3]))]
except FileNotFoundError:
    pass
KEEP = {'E6-312', 'E8-215'}
for i, v in N.items():
    st, note = v[2], v[3]
    if not st.startswith('DUBL') and i not in KEEP and 'дубль идеи' not in note:
        m = re.search(r'дубль (E\d-\d{3})', note)
        if m and m.group(1) in U and m.group(1) != i:
            v[2] = 'DUBL:' + m.group(1)
def canon(i):
    seen = set()
    while N[i][2].startswith('DUBL:'):
        seen.add(i); i = N[i][2][5:]
        assert i not in seen
    return i
dubs = collections.defaultdict(list)
for i, v in N.items():
    if v[2].startswith('DUBL:'):
        dubs[canon(i)].append(i)
def is_rej(i):
    x = U[i]; st = N[i][2]
    if i in ('E6-080', 'E6-081', 'E6-082'): return False
    if st in ('FIX', 'NOFIX', 'MOOT'): return False
    return st == 'OTV' or x['vid'] == 'otvergnuto'
KTO = {'vladelec': 'владелец', 'analitik': 'аналитик', 'subagent': 'субагент'}
TOP = {t[0]: t for t in TOPICS}
def stlabel(i, rej):
    st = N[i][2]
    if st.startswith('R') and st[1:].isdigit():
        return ('отвергнуто решением Р' if rej else 'принято решением Р') + st[1:]
    if rej and st != 'OTV':
        return 'отвергнуто; ' + STATUS.get(st, st)
    return STATUS.get(st, st)
def clean(s):
    return (s or '').replace('\n', ' ').strip()
def nd(s):
    return clean(s).rstrip('.').rstrip()
def entry(i, rej):
    x = U[i]; note = clean(N[i][3])
    ids = [i] + sorted(dubs.get(i, []))
    s = f"- {clean(x['tekst'])} — *{KTO[x['kto']]}, {x['kogda']}*"
    src = clean(x.get('istochnik'))
    if x['kto'] != 'vladelec' and src and N[i][1] != 'T15':
        s += f" ({src[:70]})"
    s += '.'
    c = clean(x.get('citata'))
    if c:
        if x['kto'] == 'vladelec': s += f" Владелец дословно: «{c}»."
        elif c not in clean(x['tekst']): s += f" Выдержка: «{c}»."

    for d in sorted(dubs.get(i, [])):
        y = U[d]
        if y['kto'] == 'vladelec' and clean(y.get('citata')) and clean(y.get('citata')) != c:
            s += f" Владелец ({y['kogda']}): «{clean(y['citata'])}»."
    if rej:
        why = nd(x.get('pochemu')); note = nd(note)
        parts = [p for p in (why, note) if p]
        s += f" **Почему:** {' — '.join(parts) if parts else 'причина в источнике не названа'}."
        lab = stlabel(i, True)
        if N[i][2] == 'OTV':
            blob = why + ' ' + note
            if x['kto'] == 'vladelec': lab = 'отвергнуто владельцем'
            elif re.search(r'Р\d{3}', blob) or re.search(r'(21:39|22:21|22:37|23:03|23:14|23:26|23:29|23:43|23:5\d|00:26|00:56|10:10|10:19|11:29)', blob) or 'ладелец' in blob or 'ладельц' in blob: lab = 'отвергнуто по слову владельца'
            else: lab = 'отвергнуто ' + ('аналитиком' if x['kto'] == 'analitik' else 'субагентом') + ' (не решение владельца)'
        s += f" **Статус:** {lab}."
    else:
        why = nd(x.get('pochemu')); note = nd(note)
        if N[i][2] == 'L10': note = re.sub(r'^в v10 — ', '', note)
        if N[i][2] == 'DOSKA': note = re.sub(r'^(на доске v10 — |экран )', lambda m: 'экран ' if m.group(0)=='экран ' else '', note)
        s += f" **Статус:** {stlabel(i, False)}" + (f" — {note}" if note else '') + '.'
        if why and x['vid'] != 'otvergnuto':
            s += f" (Причина/контекст: {why}.)"
        elif why:
            s += f" (Почему: {why}.)"
    s += ' [' + ', '.join(ids) + ']'
    return s
def kogda_key(i):
    return (U[i]['kogda'] or '', i)
canon_ids = [i for i in N if not N[i][2].startswith('DUBL:')]
bytop = collections.defaultdict(lambda: {'ok': [], 'rej': []})
for i in canon_ids:
    bytop[N[i][1]]['rej' if is_rej(i) else 'ok'].append(i)
out = []
out.append('# K4b — свод идей сессии 05.10 вечер – 06.10 (урок «Умный перебор», КР, мини-листок, лента, доска)\n')
out.append('Группа K4b: 719 единиц (ideya/otvergnuto) из экстракторов E5–E8. Финал, с которым сверено: лента v10 — `statya-urok-1/_sluzhebnoe/lenta-istochnik.md` (10:20 06.10); доска v4 — `v10doska-1791271258/DOSKA-umnyj-perebor.html` (10:21); КР — `kr610v3_1131/kontrolnaya_06-10_dannye.py` (11:31); мини-листок — `kr610v2/minilistok_06-10_dannye.py`. Решения — `docs/RESHENIYA.md` (Р-номера найдены грепом).\n')
out.append('Формат записи: суть — *кто, когда* (источник). Цитата (владельца — дословно). **Статус:** вошло в финал (лента v10 / доска / КР / мини-листок) · принято решением Р… · осталась идеей · перекрыто следующей версией · отвергнуто. В квадратных скобках — id единиц; первым стоит основной, за ним дубли. Идеи аналитика и субагентов — именно идеи, не решения владельца, пока не указан Р-номер.\n')
out.append('## Оглавление\n')
order = [t[0] for t in TOPICS]
for k, t in enumerate(TOPICS, 1):
    out.append(f"{k}. [{t[2]}](#{t[1]})")
out.append(f"{len(TOPICS)+1}. [Отвергнутое и почему](#otv)\n")
for k, t in enumerate(TOPICS, 1):
    code, anc, title, intro = t
    out.append(f'<a id="{anc}"></a>\n## {k}. {title}\n')
    out.append(intro + '\n')
    ids = sorted(bytop[code]['ok'], key=kogda_key)
    if code == 'T15':
        cnt = collections.Counter(N[i][2] for i in ids)
        out.append('Итог по находкам (без дублей): ' + ', '.join(f"{STATUS.get(k,k)} — {v}" for k, v in cnt.most_common()) + '.\n')
        groups = collections.OrderedDict()
        for i in ids:
            src = U[i]['mesto'].split(':')[1].strip() if ':' in U[i]['mesto'] and 'agent' in U[i]['istochnik'] else U[i]['istochnik']
            groups.setdefault(src[:90], []).append(i)
        for g, gi in groups.items():
            out.append(f'### {g}\n')
            for i in gi: out.append(entry(i, False))
            out.append('')
    else:
        for i in ids: out.append(entry(i, False))
        out.append('')
    if bytop[code]['rej']:
        out.append(f'Отвергнутое по этой теме — в разделе [«Отвергнутое и почему»](#otv-{anc}).\n')
out.append('<a id="otv"></a>\n## Отвергнутое и почему\n')
out.append('Каждое отвергнутое — с причиной (из источника; если не названа — так и сказано) и с тем, чьим решением.\n')
for k, t in enumerate(TOPICS, 1):
    code, anc, title, intro = t
    ids = sorted(bytop[code]['rej'], key=kogda_key)
    if not ids: continue
    out.append(f'<a id="otv-{anc}"></a>\n### {title}\n')
    for i in ids: out.append(entry(i, True))
    out.append('')
open('/mnt/user-data/outputs/izvl/dom/K4b-IDEI-05-06.md', 'w').write('\n'.join(out) + '\n')
# map
anc = {t[0]: t[1] for t in TOPICS}
rows = []
for x in L:
    i = x['id']; st = N[i][2]
    if st.startswith('DUBL:'):
        c = canon(i)
        a = ('otv-' if is_rej(c) else '') + anc[N[c][1]]
        rows.append((i, 'dubl', f'{c} → K4b-IDEI-05-06.md#{a}'))
        continue
    a = ('otv-' if is_rej(i) else '') + anc[N[i][1]]
    if st.startswith('R') and st[1:].isdigit():
        rows.append((i, 'est', f'docs/RESHENIYA.md Р{st[1:]}; свод K4b-IDEI-05-06.md#{a}'))
    else:
        rows.append((i, 'novoe', f'K4b-IDEI-05-06.md#{a}'))
with open('/mnt/user-data/outputs/izvl/dom/map-K4b.tsv', 'w') as f:
    for r in rows: f.write('\t'.join(r) + '\n')
print(collections.Counter(r[1] for r in rows), len(rows))
