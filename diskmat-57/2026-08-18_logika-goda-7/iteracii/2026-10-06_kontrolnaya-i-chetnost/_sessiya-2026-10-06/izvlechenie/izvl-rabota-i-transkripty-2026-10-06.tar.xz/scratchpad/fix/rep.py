import sys
def rep(path, pairs):
    t=open(path,encoding='utf-8').read()
    for old,new in pairs:
        n=t.count(old)
        assert n==1, (path, n, old[:80])
        t=t.replace(old,new)
    open(path,'w',encoding='utf-8').write(t)
