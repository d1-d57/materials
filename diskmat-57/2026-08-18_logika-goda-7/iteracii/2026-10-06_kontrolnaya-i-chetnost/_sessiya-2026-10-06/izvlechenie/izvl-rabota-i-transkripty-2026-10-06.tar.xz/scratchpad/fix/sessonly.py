import sys,json,glob;sys.path.insert(0,'.')
from corpus import *
U={}
for f in sorted(glob.glob('/mnt/user-data/outputs/izvl/out/E*.jsonl')):
    for l in open(f):
        if l.strip(): d=json.loads(l); U[d['id']]=d
res=[]
for i,u in U.items():
    if u.get('kto')!='vladelec' or not u.get('citata'): continue
    ps=pieces(u['citata']) or [u['citata']]
    srcs=set()
    ok_speech=all(any(norm(p) in NP[k] for k in ('OTVETY-05','OTVETY-04','4180')) or any(norm(p) in v for v in NS.values()) for p in ps)
    in_sess=all(norm(p) in NP['SESSIYA'] for p in ps)
    if not ok_speech: res.append((i,in_sess,u['istochnik'][:40],u['citata'][:110]))
for r in res: print(*r,sep=' | ')
print(len(res))
