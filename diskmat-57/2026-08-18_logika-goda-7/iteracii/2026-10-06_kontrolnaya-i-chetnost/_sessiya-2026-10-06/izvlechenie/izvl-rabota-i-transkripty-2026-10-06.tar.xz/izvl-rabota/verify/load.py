import json,glob,re,os,collections
B='/mnt/user-data/outputs/izvl'
U={}
for f in sorted(glob.glob(B+'/out/E*.jsonl')):
    for i,l in enumerate(open(f,encoding='utf-8')):
        l=l.strip()
        if not l: continue
        try: d=json.loads(l)
        except Exception as e: print('BADJSON',f,i,e); continue
        U[d['id']]=d
M={}
MAPS={}
for f in sorted(glob.glob(B+'/dom/map-*.tsv')):
    k=os.path.basename(f)[4:-4]
    MAPS[k]=[]
    for l in open(f,encoding='utf-8'):
        l=l.rstrip('\n')
        if not l: continue
        p=l.split('\t')
        while len(p)<3: p.append('')
        M.setdefault(p[0],[]).append((k,p[1],p[2]))
        MAPS[k].append(p)
DOM={os.path.basename(f):open(f,encoding='utf-8').read() for f in glob.glob(B+'/dom/*.md')+glob.glob(B+'/dom/*.txt')}
def norm(s): 
    s=s.replace(' ',' ').replace('ё','е').replace('Ё','Е')
    s=re.sub(r'[«»“”„"]','"',s); s=s.replace('—','-').replace('–','-').replace('’',"'")
    return re.sub(r'\s+',' ',s).strip()
