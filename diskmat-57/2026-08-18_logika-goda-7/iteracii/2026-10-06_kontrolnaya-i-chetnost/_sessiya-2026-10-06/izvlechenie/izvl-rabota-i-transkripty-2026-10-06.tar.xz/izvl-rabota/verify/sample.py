exec(open('load.py').read())
import random,json
rng=random.Random(20261006)
order=['K1','K2','K3','K4a','K4b','K5','K6']
def ids(k,ish): return sorted(p[0] for p in MAPS[k] if p[1]==ish)
S={'A':{},'B':{},'C':{},'D':{}}
qa={'K1':36,'K2':26,'K3':36,'K4a':36,'K4b':36,'K5':35,'K6':35}
qb={'K1':18,'K2':17,'K3':17,'K4a':17,'K4b':17,'K5':17,'K6':17}
qc={'K1':15,'K2':0,'K3':15,'K4a':4,'K4b':15,'K5':6,'K6':5}
for k in order:
    L=ids(k,'novoe'); S['A'][k]=sorted(rng.sample(L,min(qa[k],len(L))))
for k in order:
    L=ids(k,'est'); S['B'][k]=sorted(rng.sample(L,min(qb[k],len(L))))
for k in order:
    L=ids(k,'dubl'); S['C'][k]=sorted(rng.sample(L,min(qc[k],len(L))))
for e in ['E2','E5']:
    L=sorted(i for i,u in U.items() if i.startswith(e+'-') and u['kto']=='vladelec')
    print(e,'vladelec',len(L))
    S['D'][e]=sorted(rng.sample(L,40))
json.dump(S,open('sample.json','w'),ensure_ascii=False,indent=0)
print({s:{k:len(v) for k,v in S[s].items()} for s in S})
