# Граф — рёбра и сквозные нити (узел = {id})

## НИТИ — сквозные (узел = {id})
- {predel} предел/нижняя-граница | тип:рифма | лекции:[granicy, slozhnost, kriptografiya, informaciya, myshlenie] | суть:у каждой способности стена
- {os-vremeni} ось-времени 1936–50 | тип:эпоха | лекции:[granicy, optimizaciya, informaciya, sluchaynost, myshlenie]
- {sluchaynost-instrument} случайность-как-инструмент | тип:рифма | лекции:[kriptografiya, slozhnost, sluchaynost, informaciya] | суть:монетка как доказательство — Монте-Карло, Миллер–Рабин, MCMC

## РЁБРА — парные (a ~ ненапр., a -> напр.)
- granicy ~ myshlenie | тип:диагональ | ярлык:кольцо Тьюринга 1936↔1950 | где:granicy§1, myshlenie§..
- informaciya -> sluchaynost | тип:мат-идея | ярлык:предсказание=сжатие → языковые модели | где:informaciya§.., sluchaynost§..
  # тип ∈ {люди,места,эпоха,страна,мат-идея,рифма,формат-арка,в-кармане}
