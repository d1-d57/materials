# Граф — рёбра и сквозные нити (узел = {id})

## НИТИ — сквозные (узел = {id})
- {predel} предел/нижняя-граница | тип:рифма | лекции:[granicy, slozhnost, kriptografiya, informaciya, myshlenie] | суть:у каждой способности стена
- {os-vremeni} ось-времени 1936–50 | тип:эпоха | лекции:[granicy, optimizaciya, informaciya, sluchaynost, myshlenie]
- {sluchaynost-instrument} случайность-как-инструмент | тип:рифма | лекции:[kriptografiya, slozhnost, sluchaynost, informaciya] | суть:монетка как доказательство — Монте-Карло, Миллер–Рабин, MCMC
- {universalnost} универсальность | тип:рифма | лекции:[granicy, optimizaciya, slozhnost, myshlenie] | суть:одна форма за тысячей задач — машина Тьюринга, ЛП, сводимость к SAT
- {chelovek-mashina} человек→машина | тип:формат-арка | лекции:[optimizaciya, granicy, slozhnost, sluchaynost, myshlenie] | суть:искусство снабженца/счёта становится вычислением — Стиглер→симплекс→секунды
- {spryatannaya-geometriya} спрятанная-геометрия | тип:мат-идея | лекции:[optimizaciya, kriptografiya, informaciya, myshlenie] | суть:знание сидит в геометрии — вершина многогранника, коды-в-кубе, ступеньки-нейроны

## РЁБРА — парные (a ~ ненапр., a -> напр.)
- granicy ~ myshlenie | тип:диагональ | ярлык:кольцо Тьюринга 1936↔1950 | где:granicy§1, myshlenie§..
- informaciya -> sluchaynost | тип:мат-идея | ярлык:предсказание=сжатие → языковые модели | где:informaciya§.., sluchaynost§..
- optimizaciya -> myshlenie | тип:мат-идея | ярлык:оптимальный транспорт двигает массу → Stable Diffusion | где:optimizaciya§23, myshlenie§..
- optimizaciya -> slozhnost | тип:мат-идея | ярлык:симплекс быстр на практике, но экспоненциален в худшем → P vs NP | где:optimizaciya§21, slozhnost§..
- optimizaciya ~ granicy | тип:рифма | ярлык:универсальность — одна форма решает тысячу задач | где:optimizaciya§7, granicy§..
  # тип ∈ {люди,места,эпоха,страна,мат-идея,рифма,формат-арка,в-кармане}
