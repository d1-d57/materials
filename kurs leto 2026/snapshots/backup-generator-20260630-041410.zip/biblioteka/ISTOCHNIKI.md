# Источники — индекс (единственное место для ссылок)

Все внешние материалы курса одной строкой: что это / чем полезно. Новый источник — сперва сюда. Факты в работе **ссылаются** на эту строку, не переписывают (правило дедупа — `00-CHTO-GDE.md`).

> Статус «проверено» — из файлов `fakty/` (две проходки по источникам так помечали факты). Прямых URL в архиве пока нет — добавлять по мере появления.

## Книги
- **Литвак, Райгородский. «Кому нужна математика?»** (МИФ 2017 / МЦНМО 2024) — ключевой; концепция «прикладная математика вокруг» + сюжеты (аукционы, счётчики).
- **Курант, Роббинс. «Что такое математика?»** — референс глубины и честности упрощения.
- **Pickover. "The Math Book"** · **Gowers (ed.). "Princeton Companion to Mathematics"** · **Андреев. «Математическая составляющая»** (МЦНМО) — референсы охвата.
- **Roberts. "Genius at Play"** — Конвей, Игра жизни.
- **Hoffman. "The Man Who Loved Only Numbers"** · **Schechter. "My Brain Is Open"** — Эрдёш.
- **Rosenhouse. "The Monty Hall Problem"** — Монти Холл.
- **Doxiadis. "Uncle Petros and Goldbach's Conjecture"** — драматургия гипотезы.
- **"The Prime Number Conspiracy"** (Quanta / MIT Press) — сборник.
- Русские: **«Дело академика Н. Н. Лузина»** (1999) · **Колмогоров** — юбилейное (Физматлит 2003), «в воспоминаниях учеников» (ред. Ширяев, МЦНМО 2006) · **Арнольд. «Истории давние и недавние»** · **Гельфанд. «Лекции по линейной алгебре»** · **Савватеев. «Математика для гуманитариев»**.

## Видео и медиа
- **Veritasium** — Нептун, нечётные совершенные, Коллатц, мнимые числа.
- **3Blue1Brown** — Борсук–Улам, сталкивающиеся блоки = π, нейросети.
- **Numberphile** · **Quanta Magazine** (+ YouTube) · **Vsauce** · **PBS Infinite Series**.
- Фильмы: «21» (2008), «Игра в имитацию» (2014), «Игры разума».
- Журналы: Quanta, NYT Magazine, New Yorker; русские — «Квант», «Квантик», «Элементы», ПостНаука, N+1.

## Научные / архивные (проверочные)
- **Монте-Карло:** Eckhardt, Los Alamos Science 1987; Metropolis–Ulam 1949.
- **Нейросети:** McCulloch–Pitts 1943; Rosenblatt 1958; Minsky–Papert 1969; Rumelhart–Hinton–Williams 1986; Cybenko/Hornik 1989; LeCun 1989; AlexNet 2012.
- **Марков:** Hayes, "First Links in the Markov Chain" (American Scientist 2013); IEEE Spectrum 2021.
- **ЛП / прочее:** Канторович 1939; Данциг 1947; эссе Вигнера 1960; Колмогоров, «Grundbegriffe» 1933.
- **Оптимальный транспорт:** Монж 1781 (фортификации); Канторович 1942; Бренье 1987/91; Виллани (Филдс 2010); Фигалли (Филдс 2018) — арка Л-оптимизация → ML.
- **Крипто-история:** Diffie–Hellman 1976; RSA 1977 (вызов RSA-129 → разгадан 1994, «Squeamish Ossifrage»); GCHQ — Эллис/Кокс/Уильямсон 1969–73 (рассекречено 1997); Logjam 2015 (Adrian et al.); общие простые ключи 2012 (Heninger; Lenstra–Hughes).

> **Фактчек контента курса (арка «научпоп-черновик», 2026-06-29/30).** Темы выше проверены субагентами при доборе до 10/10; результат осел в `zhurnal/2026-06-28_nauchpop-chernovik/opisanie-kursa-v2/` (`teorii-v2.md` · `dokazatelstvo-v2.md` · `deystvuyushchie-lica-v2.md`) и питает единый источник правды. Исправленные ошибки исходных данных — `2-idei/kotel.md §10` + `…/kod_dobor-do-10.md §ОТЧЁТ`.

## Люди-герои (для «кочующих людей» между лекциями)
Тьюринг · фон Нейман · Шеннон · Колмогоров · Гёдель · Канторович · Нэш · Марков · Кантор · Хэмминг · Улам · Ферми · Нётер · Эрдёш · Мирзахани · June Huh · Виажовска · Понтрягин · Гельфанд · Арнольд · Лузин · Конвей · Башелье · Мандельброт.

## Методология отбора (служебное — арка «гейты-и-баллы», Ф2)
Не материал курса, а как строить инструмент оценки тем.
- **Stage-Gate** — must-meet vs should-meet критерии на гейтах: https://www.stage-gate.com/blog/the-stage-gate-model-an-overview/
- **ASQ — Decision Matrix (Pugh)** — сравнение с эталоном, относительное ранжирование: https://asq.org/quality-resources/decision-matrix
- **Decision-matrix method (Pugh)** — концепт-селекция, шкала −2…+2: https://en.wikipedia.org/wiki/Decision-matrix_method
- **ASU — Designing Effective Rubrics** — 3–5 уровней, якорные дескрипторы: https://teachonline.asu.edu/2019/02/best-practices-for-designing-effective-rubrics/
- **Statsig — Rubric design** — ловушки гало/переобучения, мало критериев, грубые шкалы: https://www.statsig.com/perspectives/rubric-design-effective-grading

## Нарратив-структура (служебное — арка «гейты-и-баллы», Шаг B)
Как строить историю внутри эпизода и серии; питает discovery-fiction-движок и ворот «антология-с-throughline» в `1-START-HERE/sistema-ocenki.md`.
- **М. Нильсен — «Discovery fiction»** — правдоподобная история о том, как результат мог быть открыт (keystone-движок): https://michaelnotebook.com/df/index.html · пример «как открыть биткоин»: https://michaelnielsen.org/ddi/how-the-bitcoin-protocol-actually-works/
- **И. Лакатос — «Proofs and Refutations»** — доказательство как путь догадок-опровержений (родословная DF): https://en.wikipedia.org/wiki/Proofs_and_Refutations
- **Т. Гауэрс — «откуда берётся нормальная подгруппа»** — мат-изложение через переоткрытие: https://gowers.wordpress.com/2011/11/20/normal-subgroups-and-quotient-groups/
- **Б. Виктор — «Explorable Explanations»** — интерактив/вайб-кодинг + предупреждение «форма ради формы» (закон Старджона → граница достаточности): http://worrydream.com/ExplorableExplanations/
- **Г. Сандерсон (3b1b)** — concrete-before-abstract, населить ум примерами до определений: https://www.3blue1brown.com/about/ · интервью Dwarkesh: https://www.dwarkesh.com/p/grant-sanderson
- **Структура серии (TV-крафт)** — антология vs season-arc, «double duty» эпизода: limited series — https://fiveable.me/tv-writing/unit-1/limited-series/study-guide/YNR2zyUJa1t2KgPM · serialized vs episodic — https://fiveable.me/tv-genres/unit-4/serialized-vs-episodic-drama-structures/study-guide/U37Wa9O8t6N3y3cS · anthology — https://fiveable.me/tv-writing/unit-1/anthology-series/study-guide/W8OQ2Kj8RxUv3zRZ

## Единый источник MD→HTML — ресёрч решений (2026-06-30, арка «единый источник»)
> Как мир решает single-source-of-truth → «красивый» HTML под наш масштаб (7 лекций + глубокий банк; правит **агент по протоколу**, не человек руками; выход — один офлайн-HTML в дизайне v3/v4). Три субагента, веб. **Вывод: брать НЕ фреймворк, а тонкий набор скриптов поверх наших plain-MD.**

**Рекомендуемый минимальный стек (вывод ресёрча):**
- **Генератор** — свой тонкий скрипт (Python `markdown-it-py` + `mdit-py-plugins` container + Jinja2-шаблон, снятый с v3/v4). Наш случай требует Python-логики: SVG-инфографика из карты, резолв `→[id]`→портрет/чип/дуга, base64-портреты, рендер с учётом счётчиков. Нулевой-код baseline для сравнения — **Pandoc** `--standalone --embed-resources` + Lua-фильтр + кастомный шаблон (одна команда, детерминизм, без npm). Сборка **двупроходная**: 1-й проход собирает все id, 2-й резолвит ссылки.
- **Бэклинки** (ядро боли «правлю тут — вижу задетое там») — ~60-строчный скрипт инвертирует прямые `→[id]` в обратный индекс `задето[id]=[(файл,цитата)]` → `link_index.json` и/или секция «## Задето» в файле. Паттерн note-link-janitor; без приложения.
- **Целостность как падающий тест** — ~120-строчный линтер читает ЖИВЫЕ файлы и валит сборку (exit 1) на: нерезолвящихся `→[id]`, сиротах, матблоках вне ~20, нарушенных квотах графа (≥3 сквозных через ≥5, ≥10 парных, лицо в 2–5). Счётчики НЕ хранятся — пересчитываются из файлов, поэтому расходиться не могут. Модель — контент-линтер GitHub Docs (60+ правил как hard-fail CI).
- **Привязка HTML↔текст** (комментировать рендер) — генератор ставит `data-source` (файл:блок) на каждый блок (sourcepos markdown-it / позиции remark) → коммент в HTML однозначно ведёт к MD-блоку. Комменты — невидимыми маркерами в MD (паттерн md-redline): агент читает → правит → стирает.
- **Граф-вид** — из индекса генерим Mermaid/DOT (~30 строк); Mermaid встроен в `karta.md` (рендерится на GitHub/в превью). Опц. богатый интерактив — Quartz v4.
- **Протокол правок** (твоё «чёткая инструкция где что править») — расширить CLAUDE/AGENTS-паттерн чек-листом **семантического рипла** по типам правок + «definition of done» + машинные маркеры `@canonical:X`/`@ref:X` (агент грепает все употребления). **Честный предел:** механический рипл автоматизируется (переименовал id → починить ссылки); семантический (сменил рамку лекции → пересмотреть манифест/таймлайн) — агент ФЛАГует «задето §X», но не решает за тебя → нужен ревью-гейт.

**Ландшафт со ссылками.** Генерация MD→офлайн-HTML: Pandoc https://pandoc.org/lua-filters.html · markdown-it-py https://github.com/executablebooks/markdown-it-py + https://mdit-py-plugins.readthedocs.io/ · markdown-customblocks https://github.com/vokimon/markdown-customblocks · remark/rehype-directive https://github.com/remarkjs/remark-rehype · Quarto (Bootstrap-связан) https://quarto.org/docs/output-formats/html-basics.html · vite-plugin-singlefile https://github.com/richardtallent/vite-plugin-singlefile. Бэклинки/DRY: note-link-janitor https://github.com/andymatuschak/note-link-janitor · wikilinks https://python-markdown.github.io/extensions/wikilinks/ · COPE https://www.lullabot.com/articles/understanding-create-once-publish-everywhere-cope · Obsidian-эмбеды ломаются на экспорте https://forum.obsidian.md/t/transclusion-on-export/3193. Линтеры: lychee https://lychee.cli.rs/overview/ · markdown-link-check https://github.com/tcort/markdown-link-check · GitHub Docs linter https://docs.github.com/en/contributing/collaborating-on-github-docs/using-the-content-linter · contextlint https://github.com/nozomi-koborinai/contextlint. Граф/привязка/агент: markdown-it-source-map https://github.com/tylingsoft/markdown-it-source-map · Quartz v4 https://quartz.jzhao.xyz/ · md-review-plus https://github.com/Seiraiyu/md-review-plus · AGENTS.md https://www.infoq.com/news/2025/08/agents-md/ · llms.txt https://limy.ai/blog/llms.txt-in-2026-the-full-guide · Mermaid/Graphviz из MD https://mdedit.ai/blog/complete-guide-to-diagrams-in-markdown.

**Ловушки.** base64-раздувание (жать PNG; SVG держать инлайн-текстом, не base64). Pandoc `--embed-resources` НЕ инлайнит `url()` из CSS — шрифты явным `@font-face{src:url(data:)}` (https://github.com/jgm/pandoc/issues/8362). Резолв `→[id]` требует двупроходной сборки. Бэклинк-индекс/граф пересобирать В сборке, не лениво (иначе фантомные рёбра). Заголовочные якоря слугаются по-разному в рендерах → наш `→[id]`, резолвимый ЛИНТЕРОМ (не рендером), это и чинит — решение об id уже верное. Семантический рипл не автоматизируется — только ревью-гейт.

**НЕ берём (оверкилл под 7 лекций):** Hugo / MkDocs-Material (тема навязана, многостранично) · Astro (JS-билд ради 7 страниц) · Sphinx/MyST (Python-билд-система) · AsciiDoc / DITA (смена тулчейна / enterprise-XML) · Obsidian/Foam/Dendron как инфраструктура (индекс в приложении/VSCode — агент не достанет) · RAG/вектора для консистентности.

---
_Источники собраны из рабочих файлов курса при аудите 2026-06-27 (`2-idei/`, `fakty/`). По мере работы — дополнять строкой и URL._
