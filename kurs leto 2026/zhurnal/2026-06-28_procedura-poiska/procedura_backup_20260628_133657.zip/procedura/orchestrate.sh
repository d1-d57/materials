#!/usr/bin/env bash
# orchestrate.sh — оркестратор-над-волнами (волна-за-волной, durable I/O).
#
# Workflow МЕЖСЕССИЙНО НЕ резюмится (стартует заново; resume только внутри сессии Code).
# Поэтому КАЖДАЯ ВОЛНА — отдельный вызов `claude -p`: читает durable-артефакт прошлой
# волны и пишет свой. Троттл 5-час окна между волнами → resume = просто перезапустить
# следующую волну (предыдущие лежат на диске в artifacts/). Внутри волны троттл →
# волна перезапускается ЦЕЛИКОМ (поэтому волны режем под комфортный размер).
#
# Использование:
#   ./orchestrate.sh all          # все 5 волн подряд
#   ./orchestrate.sh w3           # только волна 3 (resume после троттла)
#   ./orchestrate.sh w3 w4 w5     # с волны 3 до конца
#
# Тиринг моделей — через CLAUDE_CODE_SUBAGENT_MODEL (см. RUNBOOK.md). Запускать ОДИН
# инстанс (параллельные выжигают 5-час окно Max 20x вдвое быстрее). Opus — только в
# воркерах ядра w4 (через model: в их определении), не на уровне оркестратора.

set -euo pipefail

PROC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ART="$PROC_DIR/artifacts"
SCHEMA="$PROC_DIR/scorecard.schema.json"
mkdir -p "$ART"

# --- лог времени/токенов прогона (для владельца; всегда логируем) ---
RUN_LOG="$ART/run_log.txt"
RUN_START=$(date +%s)
echo "=== RUN start $(date '+%F %T %Z') ===" >> "$RUN_LOG"

# Общие флаги вызова (права пред-авторизованы, без интерактива).
COMMON_FLAGS=(--output-format json --json-schema "$SCHEMA" --bare \
  --allowedTools "Read,Write,Edit,Bash,Agent" --permission-mode acceptEdits)

run_wave () {
  local wave="$1" model="$2"
  local w_start w_end secs toks raw
  w_start=$(date +%s)
  raw="$ART/${wave}_run.json"
  echo ">>> [$wave] модель субагентов=$model  $(date '+%H:%M:%S')"
  CLAUDE_CODE_SUBAGENT_MODEL="$model" \
    claude -p "Выполни procedura/${wave}.md по контракту в procedura/. \
Читай durable-артефакт предыдущей волны из procedura/artifacts/ и запиши свой туда же. \
Промпт волны самодостаточен — следуй ему дословно." \
    "${COMMON_FLAGS[@]}" | tee "$raw"
  w_end=$(date +%s); secs=$(( w_end - w_start )); toks="?"
  if command -v jq >/dev/null 2>&1; then
    toks=$(jq -r '(.usage.input_tokens // 0) + (.usage.output_tokens // 0)' "$raw" 2>/dev/null || echo "?")
  fi
  echo "[$wave] время=${secs}s токены(in+out)=${toks}" | tee -a "$RUN_LOG"
  echo "<<< [$wave] готово  $(date '+%H:%M:%S')"
}

# Тиринг по волнам: w1=haiku (ширина), w2/w3/w5=sonnet (суждение/крафт),
# w4=sonnet на оркестраторе НО Opus в воркерах ядра (model: в их определении).
declare -A WAVE_MODEL=(
  [w1]=haiku [w2]=sonnet [w3]=sonnet [w4]=sonnet [w5]=sonnet
)

ORDER=(w1 w2 w3 w4 w5)

# Разбор аргумента: all | список волн | стартовая волна → до конца.
pick_waves () {
  if [[ $# -eq 0 || "$1" == "all" ]]; then printf '%s\n' "${ORDER[@]}"; return; fi
  if [[ $# -eq 1 && "$1" =~ ^w[1-5]$ ]]; then
    local started=0
    for w in "${ORDER[@]}"; do
      [[ "$w" == "$1" ]] && started=1
      [[ $started -eq 1 ]] && echo "$w"
    done
    return
  fi
  printf '%s\n' "$@"
}

mapfile -t WAVES < <(pick_waves "$@")
echo "Волны к прогону: ${WAVES[*]}"
for w in "${WAVES[@]}"; do
  run_wave "$w" "${WAVE_MODEL[$w]}"
done
RUN_END=$(date +%s); RUN_SECS=$(( RUN_END - RUN_START ))
echo "=== ИТОГ: общее время $(( RUN_SECS/60 ))м $(( RUN_SECS%60 ))с; токены по волнам — в $RUN_LOG ===" | tee -a "$RUN_LOG"
echo "ВСЁ. Итог — procedura/artifacts/w5_dossier.md"
