# MANIFEST — источники проекта (что где лежит)

Физическая раскладка `biblioteka/istochniki/`. Аннотации, оценка, карта покрытия — в `../istochniki-perechislitelnaya.md`. Чеклист загрузки — `SPISOK-skachat.md`.
Обновлено 2026-07-03. Все файлы **читаются** (текстовый слой), кроме отмеченного скана Loehr.

## knigi/ — книги
- `Loehr — Bijective Combinatorics (2011).pdf` — 600 стр. Единый биективный учебник (Дик · деревья · парковки · цикл-лемма). Текстовая версия, читается.
- `Stanley — Catalan Numbers (2015).pdf` — 224 стр. Каталог 214 интерпретаций (энциклопедия, не нарратив).
- `Aigner, Ziegler — Proofs from THE BOOK (RU).pdf` — глава про формулу Кэли = 4 красивых доказательства (Прюфер · Жойяль · Риордан–Реньи · Питман) + цикл-лемма.
- `Lando — Лекции о производящих функциях.pdf` — ПФ; неожиданно широк (цикл-лемма, Кэли, Прюфер).
- `Spivak — Новая школьная энциклопедия (математика).pdf` — 256 стр., картиночная школьная подача (Дик×91).

## konspekty/ — конспекты курсов (нужная «форма»)
- **`18.212 [official, Spring 2025]/`** — полный курс Постникова по лекциям (картиночный, с Drive — «тот самый»). **Нужны:** `Notes 01. Catalan Numbers`, `08. Trees`, `09. Arrangements, Parking`, `10. More Graphs`, `11. Misc Topics`. Мимо (контекст курса): 02 Young · 03 Permutations · 04 Posets · 05 More Young · 06 q-Analogs · 07 Partitions (+ `info.pdf`, `diagrams.pdf`).
- `Yu — MIT 18.212 Algebraic Combinatorics (2026).pdf` — 60 стр. ОБА МИРА в одном: §1 Каталан (Дик / цикл-сдвиги=цикл-лемма / отражение / первое возвращение Cₖ₋₁Cₙ₋ₖ / «Many bijections»); §6 остовные деревья (Кэли ×4, §6.9 парковки); §7 BEST.
- `Ko — MIT 18.212 Concise Algebraic Combinatorics.pdf` — 39 стр. §11 Parking Functions, §11.1 **Labeled Dyck Paths** (ключ владельца).
- `Ardila — Algebraic & geometric methods in enumerative combinatorics.pdf` — 143 стр. Биективные методы, деревья→Дик.
- `Vyalyi — ВШЭ ДМ, семинар 5 (числа Каталана).pdf` — короткий листок (образец жанра «листочек»).

## stati-obzory/ — статьи и обзоры
- `Yan — Parking functions (Handbook 2015).pdf` — ГЛАВНЫЙ обзор мира Кэли; единственный с «labeled Dyck», парковки↔деревья.
- `Dershowitz, Zaks — The Cycle Lemma and some applications (1990).pdf` — цикл-лемма как мост (Каталан ↔ Кэли).
- `Pollak — weakly increasing parking functions (arXiv 2511.20796).pdf` — циклический аргумент для (n+1)ⁿ⁻¹.
- `Pak — History of Catalan numbers.pdf` — история.
- `Stanley — Catalan Addendum (EC2).pdf` — 96 стр., доп. интерпретации.
- `Merzon — Диаграммы Юнга, пути на решётке и метод отражений.pdf` — отражение + пути↔определитель (RU, педагогично).
- `Spivak — Числа Каталана (статья).pdf` — три десятка определений на рисунках (жанр кристаллизации).
- `Perkinson, Yang, Yu — G-parking functions and tree inversions (arXiv 1309.2201).pdf` — ядро нити B: биективно доказывает тождество Кревераса area = инверсии деревьев через burning-алгоритм Дхара.
- `Gaydarov, Hopkins — Parking functions and tree inversions revisited (arXiv 1506.03470).pdf` — чистое современное экспозе нити B.
- `Hopkins — Parking functions and tree inversions (slides).pdf` — школьно-пригодная подача той же нити (слайды).
- `Shin — A New Bijection Between Forests and Parking Functions (arXiv 0810.0427).pdf` — нерекурсивная биекция лес ↔ парковка.
- `Armstrong, Loehr, Warrington — Rational Parking Functions and Catalan Numbers (arXiv 1403.1845).pdf` — опц., каталан-сторона: рациональные парковочные функции и числа Каталана.

## Требует внимания
- **Loehr** — читаемая текстовая версия получена (`knigi/Loehr … (2011).pdf`, 600 стр.). Старый скан 273 МБ остался в Downloads → к удалению.
- **Курс 18.212 [official] с Drive** — получен целиком в `konspekty/18.212 [official, Spring 2025]/`; нужные лекции 01, 08, 09, 10, 11.

## Ключевой синтез-таргет
Слой «помеченные пути Дика ↔ парковки ↔ деревья»: `konspekty/Ko …` §11.1 + `stati-obzory/Yan …`. С него стартует граф утверждений.
